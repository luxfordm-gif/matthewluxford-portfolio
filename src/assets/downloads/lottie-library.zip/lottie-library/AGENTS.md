# Lottie library: instructions for coding agents (Cursor, Claude Code, others)

Read these first, in this order, and follow them:

1. `CLAUDE.md`: how work happens in this library (statuses, sketches first, levels, placement, archive don't delete, notes become rules). It applies to every agent, not just Claude.
2. `BRAND.md`: the motion rules (levels 1–4 and their limits, placement, colours with one job each, easing and timing). Green and red only ever mean price up and down.
3. `NOTES.md`: every note Matt has given. Read the ones that apply before changing anything.
4. `catalog.json`: every Lottie and its level, placement, status and rules.

## Running it

```
./start.sh
```

That starts the local server (`tools/serve.py`) on http://localhost:8123 and opens the page. It needs Python 3 and nothing else.

## How the code is laid out

| Path | What it is |
| --- | --- |
| `index.html` | The page markup. |
| `assets/library.js` | All page behaviour: the grid, the detail view, Export, the Make box, Inspiration. Plain JavaScript, no build step. |
| `assets/library.css` | All styles. Design tokens are at the top (`:root`). Later blocks refine earlier ones, so check the end of the file before changing a rule. |
| `assets/pref-panel.js` | The review-only preference panel (only shows on localhost and previews). |
| `tools/serve.py` | The local server: serves the folder and handles the page's writes (status, uploads, Make it, Inspiration). It only accepts requests from the page itself (Origin and Host checks). Keep those checks. |
| `tools/config.json` | Per-computer settings: the Figma connector's read-only tools for Make it. |
| `tools/make_samples.py` | Generated the starter samples. Safe to delete once real Lotties exist. |
| `lottie/`, `_archive/`, `stills/`, `inspiration/` | The content. |

## "Make it" and Claude Code

The page's **Make it** button and **Find the Lottie** fallback run the Claude Code CLI (`claude -p`) from `tools/serve.py`. If this computer doesn't have Claude Code, everything else still works; Make it shows a message instead. To use another agent there, change `run_job()` in `tools/serve.py`.

## Rules for changes

- No build tools or frameworks unless asked: it's plain HTML, CSS and JavaScript on purpose.
- Desktop first (1280–2560 wide). Check 1280×800, 1440×900 and 2560 after layout changes.
- Keep exports matching the preview: `placeRect()` in `library.js` and the `.place-*` rules in `library.css` must agree.
