# Stills

Pitches live here before anything is animated: one folder per idea, `L<NN>-<slug>/`, with three frames (`a.svg`, `b.svg`, `c.svg` or PNGs) and one line on what each one tries.

Matt picks one, Claude animates it, and the folder stays as the record of what was considered.
