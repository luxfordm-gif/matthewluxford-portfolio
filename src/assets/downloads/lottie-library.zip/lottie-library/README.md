# Lottie library

One page with every Lottie we've made for the app, sorted by how big it sits on a page (Level 1 to 4). From the same page you can make new ones: describe what you need, Claude sketches three options, you pick one, Claude animates it.

## Using the page

- **Make a new Lottie** (the box in the middle): describe it, add screenshots (button, paste or drag) and Figma links, pick its **Size** (level) and **Placement**, then press the arrow. In a few minutes three sketches show up in **Needs you**. Pick one and Claude animates it, then it comes back to **Needs you** for a Keep or Archive.
- **The level pills** filter the grid: Level 1 Hero moment, Level 2 Section, Level 3 Card, Level 4 Detail.
- **Toolbar:** Layout (Wall, Masonry, Compare, Strip), search, Shape (1:1, 4:5, 9:16, 16:9), Placement (as set, Safe area, Edge to edge, Fill, Bottom fade), Background (Dark, White, Cream, Brand). **More** holds Motion and Safe-area guides.
- **Placement** decides where the Lottie sits in its frame. Safe area keeps the whole thing inside a margin, Edge to edge touches the edges, Fill crops, and Bottom fade sits it on the bottom edge and fades it out. Each Lottie has its own, and exports use it too.
- **Export** (open a Lottie → Export tab): **Still** gives PNG, JPEG or SVG of the frame you pick (First, Middle, Last, or the one on screen). Type the size it sits at on the page (100%), then export at 1×, 2× or 3×. **Animated** gives the Lottie file. **Copy** puts a PNG image, the SVG text or the Lottie JSON on the clipboard, ready to paste into Figma.
- **Inspiration:** add a link, a Lottie file, or a screenshot / GIF. **Find the Lottie for me** looks on the linked page for the animation file; if the page hides it, Claude searches for it. Ideas only: check the licence before using anything directly.
- **⋯ on a card:** Keep, In review or Archive. Archive asks why, moves the file to `_archive/` and notes the reason.
- **Click a card** to see it big: scrub through it, try every shape and background, or press **On a page** to see it at its real size in a page mock-up. **Make a new one like this** puts a starting sentence in the Make box.
- **Inspiration** (sidebar): drop in Lotties or links from elsewhere with a note on what you like. Ideas only, never copied.

## Levels

| Level | Name | Where | Shown at | How busy it can be |
| --- | --- | --- | --- | --- |
| 1 | Hero moment | Top of a page, one per page | 480–1200px | Lots of detail |
| 2 | Section | Beside copy | 280–520px | A short story, 2–3 steps |
| 3 | Card | Row of 3–4 small cards | 96–200px | One idea, two moves |
| 4 | Detail | Next to a price, in a button or toast | 16–48px | One move |

The exact limits are in `BRAND.md`, and each Lottie's page says whether it's "simple enough for this size".

## Running it

1. Unzip it, then open the `lottie-library` folder in Cursor, VS Code or the Claude desktop app.
2. Run `./start.sh` (or ask your coding agent to "start the Lottie library"). The page opens at http://localhost:8123. It needs Python 3 and nothing else.
3. **Make it** (the page building new Lotties) needs the Claude Code CLI installed and signed in, plus your Figma connector's read-only tools listed in `tools/config.json`. See `CLAUDE.md` → One-time setup. Without them, everything else works and Make it says so.
4. Swap the placeholder colours for your own brand tokens in `BRAND.md` and `tools/make_samples.py`.

If your network blocks the animation player's download (cdnjs), save `lottie-web` 5.12.2 into `assets/vendor/` and point `index.html` at it.

## What's in the folder

```
index.html, assets/   the page
catalog.json          every Lottie: level, status, use for / don't use for
lottie/               the Lottie files
stills/               sketches waiting to be picked
_archive/             archived Lotties
inspiration.json      ideas from elsewhere (+ inspiration/ for their files)
BRAND.md              the motion rules: levels, colours, timing
CLAUDE.md             how Claude works in this folder
NOTES.md              every note you've given
tools/serve.py        the small local server the page talks to
tools/make_samples.py made the starter samples; delete once you have your own
```
