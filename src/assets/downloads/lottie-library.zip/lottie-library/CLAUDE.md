# Lottie library: how Claude works here

This folder is a living library of approved Lottie animations, mostly showing the app's UI. Everything new grows from what's already here, so the set stays consistent. Read this file, then `BRAND.md`, `NOTES.md` and `catalog.json`, before making or changing anything.

## The files

| File | What it holds |
| --- | --- |
| `BRAND.md` | The motion rules: levels 1–4 and their limits, colours with one job each, easing and timing. |
| `catalog.json` | The levels, and every Lottie: id, name, level, file, status, use_for, not_for, tied_to, grown_from, tags, notes. The page reads it. |
| `NOTES.md` | Every note Matt has given, dated and scoped. |
| `inspiration.json` | Lotties and links from elsewhere that Matt likes. Ideas only: never copy them. |
| `stills/<id>/` | Sketches pitched before animating (a.svg, b.svg, c.svg). |
| `_archive/` | Archived Lotties. Never use or build on them. |
| `index.html` + `assets/` | The review page. |
| `tools/serve.py` | The local server the page talks to. |

## Statuses

`pitch` (three sketches, waiting for Matt to pick) → `review` (animated, waiting for Matt's yes) → `approved` (in the library). `retired` means archived. On the page these read as "Pick a sketch", "In review", "Keep" and "Archive".

## Rules

1. **Start from the library.** Look for an approved Lottie that already does the job before inventing anything.
2. **Every new Lottie grows from one of ours.** Its `grown_from` names its parent(s); its notes say what it kept and changed.
3. **Every Lottie has a level** ("1" to "4") and stays inside that level's limits in BRAND.md. If it can't, it's the wrong level.
4. **Sketches first.** Pitch three still options in `stills/<id>/` and add the entry as `pitch`. Animate only the one Matt picks, then set it to `review`. Only Matt sets `approved`.
5. **Tied to something real.** `tied_to` says which real part of the app it shows.
6. **Use for / not for.** One line each, in plain words.
7. **Green and red only mean up and down.** See BRAND.md.
8. **Archive, don't delete.** Archived files move to `_archive/` with a reason in `retired_why`.
9. **Notes become rules.** Log every note in NOTES.md with its date and scope (`just this one`, `every Level N Lottie`, `always`). Read the ones that apply before starting.

## References and placement in a request

- A request from the page can come with **reference images** (in `stills/<id>/refs/`) and **Figma links** (in the entry's `figma`). Open every image with Read and every Figma frame with the Figma tools before sketching. Match their layout and content, but draw in BRAND.md's style; never copy logos or real customer data.
- Every request has a **placement** (see BRAND.md → Placement). Record it as `placement` on the entry and compose for it.

## One-time setup on a new computer

1. Sign Claude Code in once: `claude auth login` (opens the browser).
2. Figma: run `claude mcp list`, find the Figma server's name, and put its read-only tools in `tools/config.json` → `figma_tools`, e.g. `mcp__<server>__get_screenshot`, `mcp__<server>__get_design_context`, `mcp__<server>__get_metadata`, `mcp__<server>__get_variable_defs`. Leave the list empty if there's no Figma connector.

## File conventions

- Lottie JSON goes in `lottie/` as `L<NN>-<kebab-name>.json`. Ids are never reused.
- Bodymovin 5.7 shape layers, 60fps, transparent, no fonts (text is drawn as bars). Look at the existing files for the structure.
- `.lottie` (dotLottie) files: also save a `.json` export; the page plays JSON.

## Showing work

Start the page with the `lottie-library` launch config and open `http://localhost:8123/#L<NN>`. Screenshot it at phone size (390×844) and laptop size (1280×800) before asking for sign-off.
