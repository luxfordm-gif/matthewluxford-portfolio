# Notes

Every note Matt gives, newest first. Mark a note once and it's a rule.

Scope is one of: `just here` (that Lottie only), `this kind` (every Lottie of that kind in BRAND.md), `always` (everything; also copied into BRAND.md).

Claude reads every `this kind` and `always` note that applies before starting work.

| Date | Lottie | Frame / ratio | Note | Scope |
| --- | --- | --- | --- | --- |
| 2026-11-11 | L07 Wave Lines | — | Ridgeline wave fields read as generic tech-startup motion. Retired. | always |
| 2026-11-11 | L01 Signal Pulse | — | Three rings max; four looked like a radar screen. | this kind (#live) |
