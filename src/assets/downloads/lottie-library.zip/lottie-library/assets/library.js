/* Lottie library — review page.
   Four jobs: make a new Lottie (Claude sketches, you pick, Claude animates),
   decide what's waiting on you, browse the library by level, collect
   inspiration. Writes go through tools/serve.py. */
(function () {
  "use strict";

  const RATIOS = { "1:1": 1, "4:5": 4 / 5, "9:16": 9 / 16, "16:9": 16 / 9 };
  const SHAPES = ["native", "1:1", "4:5", "9:16", "16:9"];
  const BACKDROPS = [["ink", "Dark", "#14161A"], ["white", "White", "#FFFFFF"], ["paper", "Cream", "#F5F3EE"], ["brand", "Brand", "#7A5CFA"]];
  const STATUS = {
    approved: { label: "Keep", sub: "In the library. Claude can reuse it and build on it." },
    review: { label: "In review", sub: "Moves to Needs you until you decide." },
    retired: { label: "Archive", sub: "Out of the library. Kept so Claude knows not to make it again." }
  };
  const BADGE = { review: "In review", pitch: "Pick a sketch" };
  const COLS = { "1": [2, 2, 1], "2": [3, 2, 1], "3": [4, 3, 2], "4": [6, 4, 3] };   // desktop, tablet, phone
  const PALETTE = { "#7A5CFA": "Brand", "#2BB673": "Up (green)", "#E5484D": "Down (red)", "#1C1E24": "Screen", "#2A2D35": "Card",
                    "#3A3E48": "Line", "#E8E9EC": "Text", "#8A8F98": "Muted", "#0B0C0E": "Black" };
  // Where a Lottie sits inside its frame. Each Lottie has its own (catalog "placement"); View can override.
  const PLACES = {
    safe: { label: "Safe area", sub: "The whole Lottie with a margin all round. Never cropped, whatever the frame shape." },
    whole: { label: "Edge to edge", sub: "The whole Lottie, touching the frame's edges." },
    fill: { label: "Fill", sub: "Fills the frame. Whatever falls outside gets cut." },
    bottom: { label: "Bottom, faded", sub: "Sits on the bottom edge and fades into the background." }
  };
  const SAFE = 0.1;   // matches --safe in library.css
  const STORE = "lottie-library:view", SAVED = "lottie-library:saved";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const DEFAULTS = { view: "library", q: "", ratio: "1:1", place: "auto", layout: "wall", backdrop: "ink",
                     play: reduced ? "still" : "loop", guides: "off", makeLevel: "", makePlace: "safe", level: "all" };

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const lib = $("#library"), detail = $("#detail"), menu = $("#status-menu");

  let catalog = { items: [], levels: [] }, insp = { items: [], sources: [] };
  const data = new Map(), sizes = new Map();
  let jobs = [], seenDone = new Set(), pollTimer = null, claudeOK = true;
  const dismissed = new Set(read("lottie-library:dismissed", []));
  let live = [], io = null, open = null;
  let state = read(STORE, DEFAULTS, true);
  if (!RATIOS[state.ratio]) state.ratio = "1:1";
  if (state.layout === "grid") state.layout = "wall";
  if (!["wall", "masonry", "compare", "strip"].includes(state.layout)) state.layout = "wall";
  if (!BACKDROPS.some(b => b[0] === state.backdrop)) state.backdrop = "ink";
  if (state.place !== "auto" && !PLACES[state.place]) state.place = "auto";
  if (!PLACES[state.makePlace]) state.makePlace = "safe";
  let saved = new Set(read(SAVED, []));

  // ---------------- small helpers ----------------
  function read(key, fallback, merge) {
    try { const v = JSON.parse(localStorage.getItem(key)); return merge ? Object.assign({}, fallback, v || {}) : (v || fallback); }
    catch (e) { return merge ? Object.assign({}, fallback) : fallback; }
  }
  function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) {} }
  const save = () => write(STORE, state);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const icon = id => `<svg><use href="#i-${id}"/></svg>`;
  const isInsp = it => it.id[0] === "I";
  const title = it => it.name || it.title || it.id;
  const nat = it => { const d = data.get(it.id); return d ? d.w / d.h : 1; };
  const arFor = (it, r) => (r === "native" || !RATIOS[r] ? nat(it) : RATIOS[r]);
  const levelOf = id => catalog.levels.find(l => l.id === String(id));
  const levelName = id => { const l = levelOf(id); return l ? `${l.name} · ${l.title}` : "No level"; };
  const byId = id => catalog.items.find(i => i.id === id) || insp.items.find(i => i.id === id);
  const domain = u => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch (e) { return ""; } };
  const poster = d => Math.round((d.op - d.ip) * 0.6);
  const placeOf = (it, override) => (override && override !== "auto" && PLACES[override]) ? override : (PLACES[it.placement] ? it.placement : "safe");
  // The artboard's rectangle inside a W×H frame. CSS (.place-*) mirrors this; exports use it directly.
  function placeRect(W, H, n, place) {
    let w;
    if (place === "whole") w = Math.min(W, H * n);
    else if (place === "fill") w = Math.max(W, H * n);
    else if (place === "bottom") { w = Math.min(W * 0.84, H * 1.15 * n); const h = w / n; return { x: (W - w) / 2, y: H - h * 0.92, w, h, fade: true }; }
    else w = Math.min(W * (1 - 2 * SAFE), H * (1 - 2 * SAFE) * n);
    const h = w / n;
    return { x: (W - w) / 2, y: (H - h) / 2, w, h, fade: false };
  }
  function frameClass(it, ar, place) {
    const edge = place === "safe" || (place === "whole" && Math.abs(ar - nat(it)) > 0.01);
    return "frame place-" + place + (edge ? " show-edge" : "") + (it.level === "4" ? " tiny" : "");
  }
  const ago = s => { const m = Math.floor((Date.now() / 1000 - s) / 60); return m < 1 ? "just now" : m + " min"; };

  function inView(it, view) {
    if (view === "inspiration") return isInsp(it);
    if (isInsp(it)) return false;
    if (view === "library") return it.status === "approved";
    if (view === "needs") return it.status === "review" || it.status === "pitch";
    if (view === "archive") return it.status === "retired";
    if (view === "saved") return saved.has(it.id);
    return false;
  }
  function matches(it, q) {
    if (!q) return true;
    const hay = [it.id, title(it), levelName(it.level), it.use_for, it.not_for, it.note, it.url, (it.tags || []).join(" ")].join(" ").toLowerCase();
    return q.toLowerCase().split(/\s+/).filter(w => w.length > 1).every(w => hay.includes(w.replace(/s$/, "")));
  }
  const all = () => catalog.items.concat(insp.items);
  const shown = view => all().filter(it => inView(it, view) && matches(it, state.q));
  function colorsOf(d) {
    const out = new Map();
    (function walk(o) {
      if (!o || typeof o !== "object") return;
      if (Array.isArray(o)) return o.forEach(walk);
      if ((o.ty === "fl" || o.ty === "st") && o.c && o.c.a === 0 && Array.isArray(o.c.k)) {
        const hex = "#" + o.c.k.slice(0, 3).map(v => Math.round(v * 255).toString(16).padStart(2, "0")).join("").toUpperCase();
        out.set(hex, PALETTE[hex] || hex);
      }
      Object.values(o).forEach(walk);
    })(d);
    return [...out];
  }
  function stats(it) {
    const d = data.get(it.id); if (!d) return null;
    const layers = (d.layers || []).length + (d.assets || []).reduce((n, a) => n + (a.layers || []).length, 0);
    return { layers, colours: colorsOf(d).length, seconds: (d.op - d.ip) / d.fr, kb: (sizes.get(it.id) || JSON.stringify(d).length) / 1024 };
  }

  // ---------------- lottie ----------------
  function artEl(it) {
    const art = document.createElement("div");
    art.className = "art"; art.style.setProperty("--nat", nat(it));
    art.appendChild(document.createElement("div"));
    return art;
  }
  function mount(el, it, autoplay) {
    const d = data.get(it.id); if (!d) return null;
    const a = lottie.loadAnimation({ container: el, renderer: "svg", loop: true, autoplay: false,
      animationData: structuredClone(d), rendererSettings: { preserveAspectRatio: "xMidYMid meet" } });
    a.addEventListener("DOMLoaded", () => (autoplay ? a.play() : a.goToAndStop(poster(d), true)));
    return a;
  }
  function teardown() { if (io) io.disconnect(); live.forEach(l => l.anim && l.anim.destroy()); live = []; }
  function observe() {
    io = new IntersectionObserver(es => es.forEach(en => {
      const l = live.find(x => x.el === en.target); if (!l) return;
      if (en.isIntersecting) { if (!l.anim) l.anim = mount(l.el, l.item, state.play === "loop"); else if (state.play === "loop") l.anim.play(); }
      else if (l.anim) l.anim.pause();
    }), { rootMargin: "200px" });
    live.forEach(l => io.observe(l.el));
  }

  // ---------------- cards ----------------
  function frameEl(it, ratio) {
    const f = document.createElement("div");
    const ar = arFor(it, ratio);
    f.className = frameClass(it, ar, placeOf(it, state.place));
    f.style.setProperty("--ar", ar);
    f.tabIndex = 0; f.setAttribute("role", "button"); f.setAttribute("aria-label", `Open ${title(it)}`);
    if (it.status === "pitch") {
      const opts = (it.pitch && it.pitch.options) || [];
      f.innerHTML = `<div class="pitch-thumbs">${[0, 1, 2].map(i => opts[i] && opts[i].file ? `<img src="${esc(opts[i].file)}" alt="Sketch ${esc(opts[i].key)}" loading="lazy">` : `<span class="missing">…</span>`).join("")}</div>`;
    } else if (data.has(it.id)) {
      const art = artEl(it); f.appendChild(art);
      live.push({ el: art.firstChild, item: it, anim: null });
    } else {
      f.innerHTML = linkCard(it);
    }
    if (BADGE[it.status]) f.insertAdjacentHTML("beforeend", `<span class="badge st-${it.status}">${BADGE[it.status]}</span>`);
    f.insertAdjacentHTML("beforeend", `<button class="dots" type="button" data-menu="${it.id}" aria-label="Options for ${esc(title(it))}" aria-haspopup="menu"><i></i><i></i><i></i></button>`);
    f.addEventListener("click", e => { if (!e.target.closest("[data-menu]")) openDetail(it, ratio); });
    f.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target === f) { e.preventDefault(); openDetail(it, ratio); } });
    return f;
  }
  function linkCard(it) {
    if (it.image) return `<img class="insp-img" src="${esc(it.image)}" alt="${esc(title(it))}" loading="lazy">`;
    return `<div class="link-card"><span class="dom">${esc(domain(it.url) || "link")}</span><div><div class="t">${esc(title(it))}</div><div class="nt">${esc(it.note || "")}</div></div></div>`;
  }
  function card(it, decide) {
    const c = document.createElement("article");
    c.className = "card" + (it.status === "retired" ? " is-archived" : "");
    const r = state.layout === "masonry" ? "native" : state.ratio;
    c.style.setProperty("--ar", arFor(it, r));
    c.appendChild(frameEl(it, r));
    const meta = isInsp(it) ? (domain(it.url) || "Inspiration") : it.id;
    c.insertAdjacentHTML("beforeend", `<div class="cap"><span class="name">${esc(title(it))}</span><span class="meta">${esc(meta)}</span></div>`);
    if (decide) {
      c.insertAdjacentHTML("beforeend", it.status === "pitch"
        ? `<div class="decide"><button class="btn small primary" data-open="${it.id}">Pick a sketch</button></div>`
        : `<div class="decide"><button class="btn small primary" data-set="approved" data-id="${it.id}">Keep</button><button class="btn small" data-set="retired" data-id="${it.id}">Archive</button></div>`);
    }
    return c;
  }
  function compareRows(items) {
    const box = document.createElement("div");
    items.forEach(it => {
      const row = document.createElement("section"); row.className = "crow";
      row.innerHTML = `<div class="meta"><button class="open" type="button">${esc(title(it))}</button><span class="hint" style="margin:0">${esc(it.id)}</span></div><div class="frames"></div>`;
      $(".open", row).addEventListener("click", () => openDetail(it, "native"));
      SHAPES.forEach(r => {
        const fig = document.createElement("figure");
        fig.appendChild(frameEl(it, r));
        const d = data.get(it.id);
        fig.insertAdjacentHTML("beforeend", `<figcaption>${r === "native" ? `Own shape${d ? ` ${d.w}×${d.h}` : ""}` : r}</figcaption>`);
        $(".frames", row).appendChild(fig);
      });
      box.appendChild(row);
    });
    return box;
  }
  function gridOf(items, cols, decide) {
    if (state.layout === "compare" && !decide) return compareRows(items);
    const g = document.createElement("div");
    g.className = "grid";
    g.style.setProperty("--cols", cols[0]); g.style.setProperty("--cols-md", cols[1]); g.style.setProperty("--cols-sm", cols[2]);
    items.forEach(it => g.appendChild(card(it, decide)));
    return g;
  }
  function section(id, heading, hint, body) {
    const s = document.createElement("section");
    s.className = "sec"; if (id) s.id = id;
    s.innerHTML = `<div class="sec-head"><h2>${heading}</h2>${hint ? `<p class="hint">${hint}</p>` : ""}</div>`;
    s.appendChild(body);
    return s;
  }

  // ---------------- render ----------------
  const VIEW = {
    library: ["Levels", ""],
    needs: ["Needs you", "(sketches to pick from, and new Lotties to keep or archive)"],
    inspiration: ["", ""],
    saved: ["Saved", ""],
    archive: ["Archive", "(out of the library; kept so Claude knows not to make them again)"]
  };
  function render() {
    teardown();
    syncControls();
    const v = state.view;
    $("#composer").hidden = v !== "library";
    $("#insp-bar").hidden = v !== "inspiration";
    $("#view-title").textContent = VIEW[v][0];
    $("#view-title").hidden = !VIEW[v][0];
    $("#view-hint").textContent = VIEW[v][1];
    lib.innerHTML = ""; lib.dataset.backdrop = state.backdrop;

    // Level pills: All + Level 1-4, with counts for this view
    const base = shown(v);
    const lv = state.level;
    $("#pills").hidden = v === "inspiration" && !base.some(i => i.level);
    $("#pills").innerHTML = [["all", "All", "", base.length]].concat(catalog.levels.map(l => [l.id, l.title, l.name, base.filter(i => i.level === l.id).length]))
      .map(([id, t, n, c]) => `<button role="tab" data-level="${id}" aria-selected="${id === lv}" title="${id === "all" ? "Every level" : esc(levelOf(id).sub)}">${n ? `<span class="lv">${esc(n.replace("Level ", "L"))}</span>` : ""}${esc(t)}<span class="n">${c}</span></button>`).join("");

    const items = base.filter(i => lv === "all" || i.level === lv);
    $("#count").textContent = `${items.length} ${v === "inspiration" ? "idea" : "Lottie"}${items.length === 1 ? "" : "s"}`;
    $("#q").placeholder = `Search ${items.length} ${v === "inspiration" ? "idea" : "Lottie"}${items.length === 1 ? "" : "s"}`;
    const decide = v === "needs";
    let body;
    if (state.layout === "compare" && !decide) body = compareRows(items);
    else {
      body = document.createElement("div");
      body.className = "wall" + (state.layout === "masonry" || state.layout === "strip" ? " " + state.layout : "");
      items.forEach(it => body.appendChild(card(it, decide)));
    }
    if (v === "inspiration" && state.layout !== "compare") {
      const add = document.createElement("article"); add.className = "card";
      add.innerHTML = `<button class="add-tile" type="button" data-add style="--ar:${RATIOS[state.ratio]}"><span><b>Add inspiration</b>Drop a Lottie .json, or add a link and a note</span></button>`;
      body.prepend(add);
    }
    lib.appendChild(body);
    if (!items.length && v !== "inspiration") {
      const msg = state.q ? "Nothing matches your search." :
        { library: lv === "all" ? "No Lotties yet. Describe one above and press Make it." : "Nothing at this level yet.", needs: "Nothing waiting on you.",
          saved: "Nothing saved yet. Open a Lottie and tap the bookmark.", archive: "Nothing archived." }[v];
      lib.insertAdjacentHTML("beforeend", `<p class="empty">${msg}</p>`);
    }
    observe();
  }
  function renderNav() {
    ["library", "needs", "archive", "saved", "inspiration"].forEach(v => {
      const el = $(`[data-n="${v}"]`); if (el) el.textContent = all().filter(i => inView(i, v)).length || "";
    });
    $$(".nav [data-view]").forEach(b => b.setAttribute("aria-current", String(b.dataset.view === state.view)));
  }
  function syncControls() {
    $$(".seg[data-key], .opts[data-key]").forEach(g => $$("button", g).forEach(b => b.setAttribute("aria-pressed", String(b.dataset.v === state[g.dataset.key]))));
    renderMakeChips();
    const own = state.layout === "masonry" || state.layout === "compare";
    $$('[data-key="ratio"] button').forEach(b => { b.disabled = own; b.title = own ? (state.layout === "masonry" ? "Masonry shows each Lottie in its own shape" : "Compare shows every shape") : ""; });
    document.body.classList.toggle("guides", state.guides === "on");
    if ($("#q").value !== state.q) $("#q").value = state.q;
  }
  function renderMakeChips() {
    if (!catalog.levels.length) return;
    const lv = levelOf(state.makeLevel);
    $("#size-btn").innerHTML = `Size <b>${lv ? esc(lv.name.replace("Level ", "L") + " " + lv.title) : "Not sure"}</b>${icon("caret")}`;
    $("#size-pop").innerHTML = `<div class="opts">` + [["", "Not sure", "Claude picks the level and says why."]].concat(catalog.levels.map(l => [l.id, `${l.name} · ${l.title}`, `${l.sub} ${l.size}.`]))
      .map(([id, t, sub]) => `<button type="button" data-mlv="${id}" aria-pressed="${id === state.makeLevel}"><b>${esc(t)}</b><span>${esc(sub)}</span></button>`).join("") + `</div>`;
    $("#place-btn").innerHTML = `Placement <b>${PLACES[state.makePlace].label}</b>${icon("caret")}`;
    $("#place-pop").innerHTML = `<div class="opts">` + Object.entries(PLACES)
      .map(([k, v]) => `<button type="button" data-mpl="${k}" aria-pressed="${k === state.makePlace}"><b>${v.label}</b><span>${v.sub}</span></button>`).join("") + `</div>`;
  }
  function renderPlaceOpts() {
    const short = { safe: "Safe area", whole: "Edge to edge", fill: "Fill", bottom: "Bottom fade" };
    $("#tb-place").innerHTML = [["auto", "As set", "Each Lottie uses its own placement"]].concat(Object.entries(PLACES).map(([k, v]) => [k, short[k], v.sub]))
      .map(([k, t, sub]) => `<button data-v="${k}" title="${esc(sub)}">${t}</button>`).join("");
  }
  function renderAll() { renderNav(); render(); }

  // ---------------- controls ----------------
  document.addEventListener("click", e => {
    const t = e.target;
    const seg = t.closest(".seg[data-key] button, .opts[data-key] button");
    if (seg && !seg.disabled) { state[seg.parentElement.dataset.key] = seg.dataset.v; save(); render(); return; }
    const nav = t.closest(".nav [data-view]");
    if (nav) { state.view = nav.dataset.view; state.q = ""; state.level = "all"; save(); closeSide(); renderAll(); window.scrollTo({ top: 0 }); return; }
    const pl = t.closest("#pills [data-level]");
    if (pl) { state.level = pl.dataset.level; save(); render(); return; }
    const jl = t.closest("[data-jump-level]");
    if (jl) {
      closeSide();
      if (state.view !== "library") { state.view = "library"; save(); renderAll(); }
      const s = $("#lvl-" + jl.dataset.jumpLevel); if (s) s.scrollIntoView({ behavior: "smooth" });
      return;
    }
    const mlv = t.closest("[data-mlv]");
    if (mlv) { state.makeLevel = mlv.dataset.mlv; save(); renderMakeChips(); closePops(); return; }
    const mpl = t.closest("[data-mpl]");
    if (mpl) { state.makePlace = mpl.dataset.mpl; save(); renderMakeChips(); closePops(); return; }
    const pb = t.closest("#size-btn, #place-btn");
    if (pb) { const pop = pb.nextElementSibling, show = pop.hidden; closePops(); pop.hidden = !show; pb.setAttribute("aria-expanded", String(show)); return; }
    if (t.closest("[data-add]") || t.closest("#add-insp")) return openModal();
    const op = t.closest("[data-open]");
    if (op) { const it = byId(op.dataset.open); if (it) openDetail(it); return; }
    const set = t.closest("[data-set][data-id]");
    if (set) { const it = byId(set.dataset.id); if (set.dataset.set === "retired") return openMenu(set, it, true); return setStatus(it, set.dataset.set); }
    const dots = t.closest("[data-menu]");
    if (dots) { e.stopPropagation(); return openMenu(dots, byId(dots.dataset.menu)); }
    const dis = t.closest("[data-dismiss]");
    if (dis) { dismissed.add(dis.dataset.dismiss); write("lottie-library:dismissed", [...dismissed].slice(-50)); renderJobs(); return; }
    const jobOpen = t.closest("[data-job-open]");
    if (jobOpen) { const it = byId(jobOpen.dataset.jobOpen); if (it) openDetail(it); return; }
    if (!t.closest("#status-menu")) closeMenu();
    if (!t.closest(".pop-wrap")) closePops();
  });
  function closePops() {
    togglePop(false);
    ["size", "place"].forEach(k => { $(`#${k}-pop`).hidden = true; $(`#${k}-btn`).setAttribute("aria-expanded", "false"); });
  }
  $("#view-btn").addEventListener("click", () => togglePop($("#view-pop").hidden));
  function togglePop(show) { $("#view-pop").hidden = !show; $("#view-btn").setAttribute("aria-expanded", String(show)); }
  let qt;
  $("#q").addEventListener("input", e => { clearTimeout(qt); qt = setTimeout(() => { state.q = e.target.value.trim(); save(); render(); }, 140); });
  $("#new-btn").addEventListener("click", () => {
    closeSide();
    if (state.view !== "library") { state.view = "library"; save(); renderAll(); }
    window.scrollTo({ top: 0, behavior: "smooth" }); setTimeout(() => $("#need").focus(), 250);
  });

  // ---------------- options menu (⋯) ----------------
  let menuFor = null;
  function openMenu(anchor, it, archiveNow) {
    if (!it) return;
    menuFor = it;
    if (isInsp(it)) {
      menu.innerHTML = (it.url ? `<a class="mi" href="${esc(it.url)}" target="_blank" rel="noopener">${icon("out")}<b>Open where it's from</b><span>${esc(domain(it.url))}</span></a>` : "") +
        `<button class="mi" data-mi="open">${icon("right")}<b>Open</b><span>See it bigger, at every shape</span></button>` +
        (!data.has(it.id) && it.url ? `<button class="mi" data-mi="find">${icon("search")}<b>Find the Lottie for me</b><span>Looks for the animation file behind the link</span></button>` : "") +
        `<button class="mi" data-mi="remove">${icon("trash")}<b>Remove</b><span>Take it out of Inspiration</span></button>`;
    } else if (it.status === "pitch") {
      menu.innerHTML = `<button class="mi" data-mi="open">${icon("right")}<b>Pick a sketch</b><span>See the three options</span></button>` +
        `<button class="mi" data-set-menu="retired">${icon("archive")}<b>Drop this idea</b><span>Moves it to the Archive</span></button>` + whyBox("Drop it");
    } else {
      menu.innerHTML = Object.entries(STATUS).map(([k, s]) =>
        `<button class="mi" role="menuitemradio" aria-checked="${it.status === k}" data-set-menu="${k}">${icon("check")}<b>${s.label}</b><span>${s.sub}</span></button>`).join("") + whyBox("Archive");
      $$(".mi svg", menu).forEach(s => s.classList.add("tick"));
    }
    menu.hidden = false;
    const r = anchor.getBoundingClientRect(), w = menu.offsetWidth, h = menu.offsetHeight;
    const left = Math.min(Math.max(8, r.right - w), innerWidth - w - 8);
    let top = r.bottom + 6; if (top + h > innerHeight - 8) top = Math.max(8, r.top - h - 6);
    Object.assign(menu.style, { left: left + "px", top: top + "px" });
    if (archiveNow) showWhy(); else { const f = $(".mi", menu); f && f.focus(); }
  }
  const whyBox = label => `<div class="why" hidden><input id="why" placeholder="Why? (optional, goes in Notes)" maxlength="300"><div class="row"><button class="btn small" data-why="cancel">Cancel</button><button class="btn primary small" data-why="go">${label}</button></div></div>`;
  function showWhy() { const w = $(".why", menu); if (w) { w.hidden = false; $("#why").focus(); } }
  function closeMenu() { menu.hidden = true; menuFor = null; }
  menu.addEventListener("click", e => {
    const it = menuFor; if (!it) return;
    const s = e.target.closest("[data-set-menu]");
    if (s) { if (s.dataset.setMenu === it.status) return closeMenu(); if (s.dataset.setMenu === "retired") return showWhy(); setStatus(it, s.dataset.setMenu); return closeMenu(); }
    const m = e.target.closest("[data-mi]");
    if (m) { closeMenu(); if (m.dataset.mi === "open") openDetail(it); if (m.dataset.mi === "remove") removeInsp(it); if (m.dataset.mi === "find") findLottie(it); return; }
    const w = e.target.closest("[data-why]");
    if (w) { if (w.dataset.why === "go") setStatus(it, "retired", $("#why").value.trim()); closeMenu(); }
  });
  menu.addEventListener("keydown", e => {
    if (e.key === "Escape") closeMenu();
    if (e.key === "Enter" && e.target.id === "why") { e.preventDefault(); setStatus(menuFor, "retired", e.target.value.trim()); closeMenu(); }
  });

  // ---------------- server calls ----------------
  const SERVER_MSG = "Couldn't reach the library server. Open the library through Claude (\"open the Lottie library\").";
  async function post(path, body) {
    let r;
    try { r = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); }
    catch (e) { throw new Error(SERVER_MSG); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || (r.status === 404 || r.status === 501 ? SERVER_MSG : "Something went wrong (" + r.status + ")"));
    return j;
  }
  async function setStatus(it, status, reason, quiet) {
    if (!it) return;
    const prev = it.status;
    try { const { item } = await post("api/status", { id: it.id, status, reason: reason || "" }); Object.keys(it).forEach(k => delete it[k]); Object.assign(it, item); }
    catch (err) { return toast(err.message); }
    renderAll();
    if (open && open.item.id === it.id) { renderPanel(); renderStageOpts(); }
    const word = { approved: "kept", review: "moved to review", retired: "archived" }[status];
    if (!quiet) toast(`${title(it)} ${word}`, () => setStatus(it, prev, "", true));
  }

  // ---------------- Make it ----------------
  $("#make").addEventListener("submit", async e => {
    e.preventDefault();
    const need = $("#need").value.trim();
    if (need.length < 6) { $("#need").focus(); return toast("Describe the Lottie you need in a sentence or two."); }
    if (refs.some(r => r.status === "uploading")) return toast("Still uploading your images. Try again in a moment.");
    $("#make-btn").disabled = true;
    try {
      const { job } = await post("api/make", { need, level: state.makeLevel, placement: state.makePlace,
        refs: refs.filter(r => r.path).map(r => r.path), figma: figmas.slice() });
      jobs.unshift(job); $("#need").value = "";
      refs.forEach(r => URL.revokeObjectURL(r.url)); refs = []; figmas = []; renderAttach();
      renderJobs(); poll();
      toast("Claude is sketching three options. They'll appear in Needs you.");
    } catch (err) { toast(err.message); }
    $("#make-btn").disabled = false;
  });
  $("#need").addEventListener("keydown", e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) $("#make").requestSubmit(); });

  function renderJobs() {
    const recent = jobs.filter(j => !dismissed.has(j.id) && (j.state === "running" || (j.finished && Date.now() / 1000 - j.finished < 900)));
    const x = j => `<button class="job-x" data-dismiss="${esc(j.id)}" aria-label="Close">${icon("close")}</button>`;
    const html = recent.map(j => {
      if (j.state === "running") return `<div class="job"><span class="spin" aria-hidden="true"></span>${esc(j.label)}…<span class="t">${ago(j.started)}</span></div>`;
      if (j.state === "done") return `<div class="job done">${icon("check")}${j.kind === "pitch" ? `Three sketches for ${esc(j.item)} are ready` : j.kind === "find" ? `Found the Lottie for ${esc(j.item)}` : `${esc(j.item)} is animated and in review`}<button class="btn small primary" data-job-open="${esc(j.item)}">${j.kind === "pitch" ? "Pick one" : "Have a look"}</button>${x(j)}</div>`;
      return `<div class="job failed"><span>That didn't work. ${esc(j.message || "No reason given.")}</span>${x(j)}</div>`;
    });
    $("#jobs").innerHTML = recent.map((j, i) => j.kind === "find" ? "" : html[i]).join("");
    $("#insp-jobs").innerHTML = recent.map((j, i) => j.kind === "find" ? html[i] : "").join("");
    if (!claudeOK) $("#make-hint").textContent = "(Claude Code isn't installed on this computer, so Make it can't run here. Paste the description into Claude instead.)";
  }
  async function poll() {
    clearTimeout(pollTimer);
    try {
      const r = await fetch("api/jobs", { cache: "no-store" });
      if (!r.ok) throw new Error();
      const j = await r.json();
      claudeOK = j.claude !== false;
      const finished = j.jobs.filter(x => x.state !== "running" && !seenDone.has(x.id));
      jobs = j.jobs;
      if (finished.length) {
        finished.forEach(x => seenDone.add(x.id));
        if (booted) {
          await reload();
          const ok = finished.find(x => x.state === "done");
          const bad = finished.find(x => x.state === "failed" && x.kind === "find");
          if (ok) toast(ok.kind === "pitch" ? `Sketches for ${ok.item} are ready in Needs you` : ok.kind === "find" ? `Found the Lottie for ${ok.item}` : `${ok.item} is animated and waiting in Needs you`);
          else if (bad) toast(bad.message);
        }
      }
      renderJobs();
      if (jobs.some(x => x.state === "running")) pollTimer = setTimeout(poll, 4000);
    } catch (e) { /* plain file server: no jobs */ }
  }
  async function reload() {
    const [c] = await loadJSON("catalog.json");
    catalog = c;
    try { [insp] = await loadJSON("inspiration.json"); } catch (e) {}
    await loadFiles(catalog.items.concat(insp.items));
    renderAll();
    if (open) { const it = byId(open.item.id); if (it) openDetail(it, open.ratio); else closeDetail(); }
  }

  // ---------------- Make box: reference images + Figma links ----------------
  let refs = [], figmas = [];
  const FIGMA_RE = /^https:\/\/(www\.)?figma\.com\/(design|file|proto|board)\/[A-Za-z0-9]+/;
  function figmaLabel(u) {
    try {
      const url = new URL(u), parts = url.pathname.split("/").filter(Boolean);
      const name = parts[2] ? decodeURIComponent(parts[2]).replace(/-/g, " ") : "Figma file";
      const node = url.searchParams.get("node-id");
      return node ? `${name} · ${node}` : name;
    } catch (e) { return "Figma link"; }
  }
  function renderAttach() {
    const box = $("#attach");
    box.hidden = !refs.length && !figmas.length;
    box.innerHTML = refs.map((r, i) => `<div class="thumb${r.status === "uploading" ? " uploading" : ""}${r.status === "failed" ? " failed" : ""}" title="${esc(r.name)}"><img src="${r.url}" alt="">${r.status === "uploading" ? '<span class="spin"></span>' : ""}<button type="button" class="x" data-rmref="${i}" aria-label="Remove ${esc(r.name)}">${icon("close")}</button></div>`).join("") +
      figmas.map((u, i) => `<span class="fchip" title="${esc(u)}">${icon("figma")}<span>${esc(figmaLabel(u))}</span><button type="button" class="x" data-rmfig="${i}" aria-label="Remove Figma link">${icon("close")}</button></span>`).join("");
  }
  function addImages(files) {
    files.forEach(file => {
      if (!/^image\/(png|jpeg|webp|gif)$/.test(file.type)) return toast(`${file.name}: only PNG, JPEG, WebP or GIF images`);
      if (file.size > 15e6) return toast(`${file.name} is over 15MB`);
      const r = { name: file.name || "pasted-image.png", url: URL.createObjectURL(file), status: "uploading", path: null };
      refs.push(r);
      const fr = new FileReader();
      fr.onload = async () => {
        try { const { path } = await post("api/upload", { name: r.name, data: fr.result }); r.path = path; r.status = "done"; }
        catch (err) { r.status = "failed"; toast(err.message); }
        renderAttach();
      };
      fr.readAsDataURL(file);
    });
    renderAttach();
  }
  $("#attach").addEventListener("click", e => {
    const ri = e.target.closest("[data-rmref]"), fi = e.target.closest("[data-rmfig]");
    if (ri) { const [r] = refs.splice(+ri.dataset.rmref, 1); if (r) URL.revokeObjectURL(r.url); renderAttach(); }
    if (fi) { figmas.splice(+fi.dataset.rmfig, 1); renderAttach(); }
  });
  $("#add-img").addEventListener("click", () => $("#ref-file").click());
  $("#ref-file").addEventListener("change", e => { addImages([...e.target.files]); e.target.value = ""; });
  $("#need").addEventListener("paste", e => {
    const imgs = [...((e.clipboardData && e.clipboardData.files) || [])].filter(f => f.type.startsWith("image/"));
    if (imgs.length) { e.preventDefault(); addImages(imgs); }
  });
  $("#add-figma").addEventListener("click", () => { const box = $("#figma-add"); box.hidden = !box.hidden; if (!box.hidden) $("#figma-url").focus(); });
  function addFigma() {
    const found = $("#figma-url").value.split(/\s+/).map(s => s.trim()).filter(Boolean);
    const good = found.filter(u => FIGMA_RE.test(u));
    if (!good.length) return toast("That doesn't look like a Figma link (figma.com/design/…).");
    good.forEach(u => { if (!figmas.includes(u)) figmas.push(u); });
    if (good.length < found.length) toast("Some of that wasn't a Figma link, so I skipped it.");
    $("#figma-url").value = ""; $("#figma-add").hidden = true; renderAttach();
  }
  $("#figma-ok").addEventListener("click", addFigma);
  $("#figma-cancel").addEventListener("click", () => { $("#figma-url").value = ""; $("#figma-add").hidden = true; });
  $("#figma-url").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); addFigma(); } if (e.key === "Escape") $("#figma-cancel").click(); });

  // ---------------- Export: Still (PNG / JPEG / SVG) or Animated (Lottie) ----------------
  const bgHex = v => (BACKDROPS.find(b => b[0] === v) || BACKDROPS[0])[2];
  function setTab(tab) {
    if (!open) return;
    open.tab = tab;
    if (tab === "export") { open.mode = "frame"; initExport(); renderExport(); }
    renderStageOpts(); stage();
  }
  function initExport() {
    const it = open.item, d = data.get(it.id); if (!d) return;
    const lv = levelOf(it.level), ar = arFor(it, open.ratio);
    const remembered = read("lottie-library:export:" + (it.level || "x"), {});
    const w = remembered.w || (lv && lv.export_w) || 320;
    open.x = Object.assign({ mode: "still", format: "png", scale: 2, bg: "transparent", lock: true }, remembered,
      { w, h: Math.max(1, Math.round(w / ar)), frame: d.op - d.ip - 1 });
  }
  function rememberExport() {
    const x = open.x;
    write("lottie-library:export:" + (open.item.level || "x"), { mode: x.mode, format: x.format, scale: x.scale, bg: x.bg, lock: x.lock, w: x.w });
  }
  function renderExport() {
    const x = open.x, it = open.item, d = data.get(it.id); if (!x || !d) return;
    const frames = d.op - d.ip, still = x.mode === "still";
    const formats = still ? [["png", "PNG"], ["jpeg", "JPEG"], ["svg", "SVG"]] : [["lottie", "Lottie (.json)"]];
    if (!formats.some(f => f[0] === x.format)) x.format = formats[0][0];
    const raster = x.format === "png" || x.format === "jpeg";
    if (x.format === "jpeg" && x.bg === "transparent") x.bg = open.backdrop;
    const seg = (id, opts, cur) => `<div class="seg" id="${id}">${opts.map(([v, l, extra]) => `<button type="button" data-v="${v}" aria-pressed="${v === cur}">${extra || ""}${l}</button>`).join("")}</div>`;
    const sec = (t, body, note) => `<div class="x-section"><h3>${t}</h3>${body}${note ? `<p class="x-note">${note}</p>` : ""}</div>`;
    $("#x-body").innerHTML = [
      sec("What to export", seg("x-mode", [["still", "Still"], ["animated", "Animated"]], x.mode),
        still ? "(a single frame, for sections that shouldn't move)" : "(the Lottie file, playing)"),
      still ? sec("Frame", `<div class="x-frame"><input type="range" id="x-frame" min="0" max="${frames - 1}" value="${x.frame}" aria-label="Frame to export"><span class="tc" id="x-frame-t">${(x.frame / d.fr).toFixed(2)}s</span></div>
        <div class="x-row"><button type="button" class="chipbtn" data-xf="first">First</button><button type="button" class="chipbtn" data-xf="middle">Middle</button><button type="button" class="chipbtn" data-xf="last">Last</button><button type="button" class="chipbtn" data-xf="current">Use the frame on screen</button></div>`,
        "(Last is the resting pose for animations that play once)") : "",
      sec("Format", seg("x-format", formats, x.format), x.format === "svg" ? "(vector: sharp at any size; pastes straight into Figma)" : ""),
      sec("Size on the page", `<div class="x-size"><label>W<input id="x-w" inputmode="numeric" value="${x.w}" aria-label="Width in pixels"></label>
        <button type="button" class="lock" id="x-lock" aria-pressed="${x.lock}" title="${x.lock ? "Ratio locked" : "Ratio unlocked"}" aria-label="Lock the ratio">${icon(x.lock ? "lock" : "unlock")}</button>
        <label>H<input id="x-h" inputmode="numeric" value="${x.h}" aria-label="Height in pixels"></label><span class="x-note">px</span></div>`,
        still ? "(type the size it sits at on the page, at 100%)" : "(set the Lottie player to this size on the page; the file itself is vector)"),
      raster ? sec("Export at", seg("x-scale", [[1, "1×"], [2, "2×"], [3, "3×"]], x.scale), "(2× keeps it sharp on Retina screens)") : "",
      still ? sec("Background", seg("x-bg", (x.format === "jpeg" ? [] : [["transparent", "None"]]).concat(BACKDROPS.map(([v, l, c]) => [v, l, `<i class="sw" style="--c:${c}"></i>`])), x.bg),
        x.format === "jpeg" ? "(JPEG can't be see-through, so it needs a colour)" : "") : "",
      still ? `<p class="x-note">Placement (${PLACES[open.place].label}) is set under the preview, and the preview shows exactly what you'll get.</p>` : ""
    ].join("");
    renderSummary();
  }
  function renderSummary() {
    const x = open.x, d = data.get(open.item.id); if (!x) return;
    let s;
    if (x.mode === "animated") s = `<b>Lottie (.json)</b> · plays at ${x.w} × ${x.h} px · ${((d.op - d.ip) / d.fr).toFixed(1)}s`;
    else {
      const what = x.format === "svg" ? `<b>SVG · ${x.w} × ${x.h}</b>` : `<b>${x.format.toUpperCase()} · ${x.w * x.scale} × ${x.h * x.scale} px</b> (${x.w} × ${x.h} at ${x.scale}×)`;
      s = `${what} · ${x.bg === "transparent" ? "transparent" : (BACKDROPS.find(b => b[0] === x.bg) || [0, ""])[1].toLowerCase() + " background"} · frame at ${(x.frame / d.fr).toFixed(2)}s · ${PLACES[open.place].label.toLowerCase()}`;
    }
    $("#x-summary").innerHTML = s;
    $("#x-copy").innerHTML = `${icon("copy")}${x.mode === "animated" ? "Copy Lottie" : x.format === "svg" ? "Copy SVG" : "Copy image"}`;
  }
  function exportClick(t) {
    const x = open.x; if (!x) return false;
    const b = t.closest("[id^='x-'] > button[data-v]");
    if (b) {
      const key = b.parentElement.id.slice(2), v = b.dataset.v;
      if (key === "mode") { x.mode = v; x.format = v === "still" ? "png" : "lottie"; }
      if (key === "format") x.format = v;
      if (key === "scale") x.scale = +v;
      if (key === "bg") { x.bg = v; if (v !== "transparent") { open.backdrop = v; renderStageOpts(); } }
      rememberExport(); renderExport();
      if (key === "mode") stage();
      return true;
    }
    const xf = t.closest("[data-xf]");
    if (xf) {
      const d = data.get(open.item.id), last = d.op - d.ip - 1, a = open.anims[0];
      x.frame = { first: 0, middle: Math.round(last / 2), last, current: a ? Math.min(last, Math.round(a.currentFrame)) : last }[xf.dataset.xf];
      open.anims.forEach(an => an.goToAndStop(x.frame, true)); syncPlay();
      $("#x-frame").value = x.frame; $("#x-frame-t").textContent = (x.frame / d.fr).toFixed(2) + "s"; renderSummary();
      return true;
    }
    if (t.closest("#x-lock")) { x.lock = !x.lock; rememberExport(); renderExport(); return true; }
    return false;
  }
  $("#x-body").addEventListener("input", e => {
    const x = open && open.x; if (!x) return;
    const t = e.target, d = data.get(open.item.id);
    if (t.id === "x-frame") {
      x.frame = +t.value; open.anims.forEach(a => a.goToAndStop(x.frame, true)); syncPlay();
      $("#x-frame-t").textContent = (x.frame / d.fr).toFixed(2) + "s"; renderSummary(); return;
    }
    if (t.id === "x-w" || t.id === "x-h") {
      const v = Math.max(1, Math.min(8000, parseInt(t.value.replace(/\D/g, ""), 10) || 0)); if (!v) return;
      const ratio = x.w / x.h;
      if (t.id === "x-w") { x.w = v; if (x.lock) { x.h = Math.max(1, Math.round(v / ratio)); $("#x-h").value = x.h; } }
      else { x.h = v; if (x.lock) { x.w = Math.max(1, Math.round(v * ratio)); $("#x-w").value = x.w; } }
      $("#stage-frame").style.setProperty("--ar", x.w / x.h);
      rememberExport(); renderSummary();
    }
  });
  function exportName() {
    const it = open.item, x = open.x, d = data.get(it.id);
    const base = (it.file || it.id).split("/").pop().replace(/\.json$/i, "");
    if (x.mode === "animated") return base + ".json";
    const size = x.format === "svg" ? `${x.w}x${x.h}` : `${x.w}x${x.h}@${x.scale}x`;
    return `${base}_still-${(x.frame / d.fr).toFixed(2)}s_${size}.${x.format === "jpeg" ? "jpg" : x.format}`;
  }
  function whenLoaded(anim) { return new Promise(res => (anim.isLoaded ? res() : anim.addEventListener("DOMLoaded", res))); }
  // PNG/JPEG are drawn from the same SVG the preview uses, so every format matches what you see.
  // (lottie's canvas renderer drops some strokes, so it isn't used.)
  async function renderRaster(type) {
    const x = open.x;
    const PW = Math.round(x.w * x.scale), PH = Math.round(x.h * x.scale);
    const svg = await renderSVG(x.scale, false);
    const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
    try {
      const img = new Image();
      img.decoding = "sync";
      await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error("the image couldn't be drawn")); img.src = url; });
      const out = document.createElement("canvas"); out.width = PW; out.height = PH;
      const ctx = out.getContext("2d");
      const bg = x.bg === "transparent" ? (type === "image/jpeg" ? bgHex(open.backdrop) : null) : bgHex(x.bg);
      if (bg) { ctx.fillStyle = bg; ctx.fillRect(0, 0, PW, PH); }
      ctx.drawImage(img, 0, 0, PW, PH);
      return await new Promise((res, rej) => out.toBlob(b => (b ? res(b) : rej(new Error("the image couldn't be made"))), type, 0.92));
    } finally { URL.revokeObjectURL(url); }
  }
  async function renderSVG(scale = 1, withBg = true) {
    const x = open.x, d = data.get(open.item.id), W = x.w, H = x.h;
    const r = placeRect(W, H, d.w / d.h, open.place), f = n => +n.toFixed(2);
    const holder = document.createElement("div");
    holder.style.cssText = `position:fixed;left:-20000px;top:0;width:${Math.max(1, r.w)}px;height:${Math.max(1, r.h)}px;`;
    document.body.appendChild(holder);
    const anim = lottie.loadAnimation({ container: holder, renderer: "svg", loop: false, autoplay: false, animationData: structuredClone(d),
      rendererSettings: { preserveAspectRatio: "xMidYMid meet", progressiveLoad: false } });
    await whenLoaded(anim);
    anim.goToAndStop(x.frame, true);
    const inner = holder.querySelector("svg").innerHTML;
    anim.destroy(); holder.remove();
    const bg = x.bg === "transparent" || !withBg ? "" : `<rect width="${W}" height="${H}" fill="${bgHex(x.bg)}"/>`;
    const body = `<svg x="${f(r.x)}" y="${f(r.y)}" width="${f(r.w)}" height="${f(r.h)}" viewBox="0 0 ${d.w} ${d.h}" preserveAspectRatio="xMidYMid meet">${inner}</svg>`;
    const fade = r.fade ? `<defs><linearGradient id="llFadeG" gradientUnits="userSpaceOnUse" x1="0" y1="${f(r.y + r.h * 0.5)}" x2="0" y2="${f(r.y + r.h * 0.92)}"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#000"/></linearGradient><mask id="llFade" maskUnits="userSpaceOnUse" x="0" y="0" width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="url(#llFadeG)"/></mask></defs>` : "";
    return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${Math.round(W * scale)}" height="${Math.round(H * scale)}" viewBox="0 0 ${W} ${H}">${fade}${bg}${r.fade ? `<g mask="url(#llFade)">${body}</g>` : body}</svg>`;
  }
  function downloadBlob(blob, name) {
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  async function runExport(kind) {
    const x = open && open.x; if (!x) return;
    const d = data.get(open.item.id), name = exportName();
    try {
      if (x.mode === "animated") {
        const txt = JSON.stringify(d);
        if (kind === "copy") return copy(txt, "Lottie copied (animated).");
        downloadBlob(new Blob([txt], { type: "application/json" }), name); return toast(`Downloaded ${name}`);
      }
      if (x.format === "svg") {
        const svg = await renderSVG();
        if (kind === "copy") return copy(svg, "SVG copied. Paste it into Figma.");
        downloadBlob(new Blob([svg], { type: "image/svg+xml" }), name); return toast(`Downloaded ${name}`);
      }
      if (kind === "copy") {   // the clipboard only takes PNG, so a JPEG copies as PNG with its background
        const jpegBg = x.format === "jpeg" && x.bg === "transparent";
        await navigator.clipboard.write([new ClipboardItem({ "image/png": renderRaster("image/png") })]);
        return toast(x.format === "jpeg" || jpegBg ? "Copied as a PNG (the clipboard only takes PNG images)." : "Image copied. Paste it into Figma, Slack or Keynote.");
      }
      downloadBlob(await renderRaster(x.format === "jpeg" ? "image/jpeg" : "image/png"), name);
      toast(`Downloaded ${name}`);
    } catch (err) { toast("Couldn't export: " + (err.message || err)); }
  }
  window.__lottieExport = { renderRaster: t => renderRaster(t), renderSVG: () => renderSVG(), name: () => exportName() };   // for checks from the console

  // ---------------- detail ----------------
  function list() { const v = all().filter(it => inView(it, state.view)); return v.some(i => open && i.id === open.item.id) ? v : all(); }
  function openDetail(it, ratio) {
    closeMenu();
    const keep = open ? { mode: open.mode === "picks" ? "frame" : open.mode, backdrop: open.backdrop, tab: open.tab } : { mode: "frame", backdrop: state.backdrop, tab: "about" };
    killAnims();
    open = Object.assign({ item: it, ratio: ratio || state.ratio, anims: [], place: placeOf(it, state.place) }, keep);
    if (!data.has(it.id) || it.status === "pitch") open.tab = "about";
    if (open.tab === "export") { open.mode = "frame"; initExport(); }
    if (it.status === "pitch") open.mode = "picks";
    detail.classList.add("open"); detail.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    history.replaceState(null, "", "#" + it.id);
    renderStageOpts(); renderPanel(); stage();
    if (matchMedia("(pointer: fine)").matches) $("#d-close").focus({ preventScroll: true });
  }
  function killAnims() { if (open) { open.anims.forEach(a => a.destroy()); open.anims = []; } }
  function closeDetail() {
    killAnims(); open = null;
    detail.classList.remove("open"); detail.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    history.replaceState(null, "", location.pathname + location.search);
  }
  function step(dir) { if (!open) return; const l = list(), i = l.findIndex(x => x.id === open.item.id); if (l[i + dir]) openDetail(l[i + dir], open.ratio); }
  function renderStageOpts() {
    const it = open.item, has = data.has(it.id);
    $$("#d-mode button").forEach(b => { b.setAttribute("aria-pressed", String(b.dataset.m === open.mode)); b.disabled = !has || (b.dataset.m === "context" && !levelOf(it.level)); });
    $("#d-ratios").innerHTML = SHAPES.map(r => `<button data-r="${r}" aria-pressed="${r === open.ratio}">${r === "native" ? "Own shape" : r}</button>`).join("");
    $("#d-place").innerHTML = Object.entries(PLACES).map(([k, v]) => `<button data-pl="${k}" aria-pressed="${k === open.place}" title="${esc(v.sub)}">${v.label}</button>`).join("");
    const ex = open.tab === "export";
    $("#d-mode").hidden = ex; $("#d-ratios").hidden = ex;
    $$("#p-tabs button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.tab === open.tab)));
    $("#p-tabs").hidden = !has || it.status === "pitch";
    $("#d-body").hidden = ex; $("#d-actions").hidden = ex || it.status === "pitch";
    $("#x-body").hidden = !ex; $("#x-actions").hidden = !ex;
    $("#d-bd").innerHTML = BACKDROPS.map(([v, l, c]) => `<button data-bd="${v}" aria-pressed="${v === open.backdrop}" title="${l} background"><i class="sw" style="--c:${c}"></i><span>${l}</span></button>`).join("");
    detail.dataset.backdrop = open.backdrop;
    const st = $(".stage");
    st.classList.toggle("mode-context", open.mode === "context" && has);
    st.classList.toggle("mode-picks", open.mode === "picks");
    $("#transport").style.visibility = has && open.mode !== "picks" ? "" : "hidden";
    const l = list(), i = l.findIndex(x => x.id === it.id);
    $("#d-prev").disabled = i <= 0; $("#d-next").disabled = i === -1 || i >= l.length - 1;
  }
  function stage() {
    killAnims();
    const it = open.item, f = $("#stage-frame"), ctx = $("#context"), picks = $("#picks");
    f.innerHTML = ""; ctx.innerHTML = ""; picks.innerHTML = "";
    if (open.mode === "picks") {
      const opts = (it.pitch && it.pitch.options) || [];
      picks.innerHTML = opts.map(o => `<div class="pick"><div class="img">${o.file ? `<img src="${esc(o.file)}" alt="Sketch ${esc(o.key)}">` : ""}</div><span class="k">Option ${esc((o.key || "").toUpperCase())}</span><p class="idea">${esc(o.idea || "")}</p><button class="btn primary small" data-pick="${esc(o.key)}">Animate this one</button></div>`).join("") ||
        `<p class="empty">The sketches aren't there yet.</p>`;
      return;
    }
    const ex = open.tab === "export" && open.x;
    const ar = ex ? open.x.w / open.x.h : arFor(it, open.ratio);
    f.className = frameClass(it, ar, open.place).replace("frame ", "frame stage-frame ") + (ex ? " exporting" : "");
    f.style.setProperty("--ar", ar);
    if (!data.has(it.id)) {
      f.innerHTML = linkCard(it);
      return;
    }
    if (open.mode === "context" && levelOf(it.level)) {
      ctx.innerHTML = contextHTML(it);
      $$(".lot-slot", ctx).forEach(s => { s.style.setProperty("--nat", nat(it)); const a = mount(s.firstChild, it, true); a && open.anims.push(a); });
    } else {
      const art = artEl(it); f.appendChild(art);
      const still = ex && open.x.mode === "still";
      const a = mount(art.firstChild, it, !still); a && open.anims.push(a);
      if (a && still) a.addEventListener("DOMLoaded", () => a.goToAndStop(open.x.frame, true));
    }
    const d = data.get(it.id), main = open.anims[0];
    $("#d-scrub").max = Math.max(0, d.op - d.ip - 1);
    if (!main) return;
    main.addEventListener("enterFrame", () => { $("#d-scrub").value = Math.floor(main.currentFrame); tc(); });
    main.addEventListener("DOMLoaded", () => setTimeout(syncPlay));
    syncPlay();
  }
  // Wireframes of where each level lives, with the Lottie at its real size.
  function contextHTML(it) {
    const slot = `<div class="lot-slot"><div></div></div>`;
    const bars = (n, h) => `<div class="bars">${h ? '<i class="h"></i>' : ""}${"<i></i>".repeat(n)}<i class="s"></i></div>`;
    const lv = levelOf(it.level), label = `<div class="ctx-label">${esc(lv.name)} · ${esc(lv.title)} · shown at ${esc(lv.size)}</div>`;
    if (lv.id === "1") return `<div class="ctx ctx-1">${label}${bars(1, true)}${slot}</div>`;
    if (lv.id === "2") return `<div class="ctx ctx-2"><div>${label}<br>${bars(3, true)}</div>${slot}</div>`;
    if (lv.id === "3") return `<div class="ctx ctx-3">${label}${bars(0, true)}<div class="row">${`<div class="c">${slot}${bars(1)}</div>`.repeat(4)}</div></div>`;
    return `<div class="ctx ctx-4">${label}<div class="pricerow">$64,210.18 ${slot}</div><div class="toastmock">${slot}Order placed</div></div>`;
  }
  function renderPanel() {
    const it = open.item, ours = !isInsp(it), d = data.get(it.id), lv = levelOf(it.level);
    $("#d-id").textContent = it.id;
    $("#d-name").textContent = title(it);
    $("#d-sub").textContent = ours ? levelName(it.level) : `Inspiration${it.url ? " · " + domain(it.url) : ""}`;
    $("#d-export").hidden = !d;
    $("#d-save").innerHTML = icon(saved.has(it.id) ? "bookmark-on" : "bookmark");
    $("#d-grow").textContent = ours ? "Make a new one like this" : "Make our own version";
    const grp = (t, body) => body ? `<div class="grp"><h3>${t}</h3>${body}</div>` : "";
    const link = id => { const x = byId(id); return `<button class="chip" data-jump="${id}">${x ? esc(title(x)) : id}</button>`; };
    const more = rows => `<details class="more"><summary>More details</summary><div class="more-body">${rows.join("")}</div></details>`;
    const colours = d ? grp("Colours", `<div class="chips">${colorsOf(d).map(([hex, n]) => `<span class="chip" title="${hex}"><i class="sw" style="--c:${hex}"></i>${esc(n)}</span>`).join("")}</div>`) : "";
    const file = d ? grp("File", `<div class="spec">${d.w}×${d.h}px · ${((d.op - d.ip) / d.fr).toFixed(1)} seconds<br>${esc(it.file || "")}</div>`) : "";
    const size = lv ? grp("Size on the page", `<p>${esc(lv.sub)} Shown at ${esc(lv.size)}.</p>${verdictHTML(it, lv)}`) : "";
    const placeG = !isInsp(it) ? grp("Placement", `<p>${PLACES[placeOf(it)].label}: ${esc(PLACES[placeOf(it)].sub.toLowerCase())}</p>`) : "";
    const refsG = (it.refs || []).length || (it.figma || []).length ? grp("References", `<div class="refs">${(it.refs || []).map(r => `<a href="${esc(r)}" target="_blank"><img src="${esc(r)}" alt="Reference image"></a>`).join("")}</div>${(it.figma || []).length ? `<div class="chips" style="margin-top:6px">${it.figma.map(u => `<a class="chip" href="${esc(u)}" target="_blank" rel="noopener">${icon("figma")}${esc(figmaLabel(u))}</a>`).join("")}</div>` : ""}`) : "";
    if (it.status === "pitch") {
      $("#d-body").innerHTML = [grp("What you asked for", `<p>${esc((it.pitch || {}).need || "")}</p>`), size, placeG, refsG,
        grp("Next", `<p>Pick one of the three sketches. Claude animates it and it comes back here as "In review".</p>`),
        grp("", `<button class="btn small" data-set-panel="retired">${icon("archive")}Drop this idea</button>`)].join("");
    } else if (ours) {
      const kids = catalog.items.filter(i => (i.grown_from || []).includes(it.id));
      $("#d-body").innerHTML = [
        grp("Status", `<div class="chips">${Object.entries(STATUS).map(([k, s]) => `<button class="chip" data-st="${k}" aria-pressed="${it.status === k}">${s.label}</button>`).join("")}</div>${it.retired_why ? `<p class="not" style="margin-top:8px">Archived: ${esc(it.retired_why)}</p>` : ""}`),
        grp("Use it for", `<p>${esc(it.use_for)}</p>`),
        grp("Don't use it for", `<p class="not">${esc(it.not_for)}</p>`),
        size, placeG,
        more([
          refsG,
          (it.grown_from || []).length ? grp("Based on", `<div class="chips">${it.grown_from.map(link).join("")}</div>`) : "",
          kids.length ? grp("Led to", `<div class="chips">${kids.map(k => link(k.id)).join("")}</div>`) : "",
          it.tied_to ? grp("What it shows", `<p>${esc(it.tied_to)}</p>`) : "",
          it.notes ? grp("Notes", `<p>${esc(it.notes)}</p>`) : "",
          lv ? grp("Detail check", budgetHTML(it, lv)) : "",
          colours, file
        ])
      ].join("");
    } else {
      $("#d-body").innerHTML = [
        grp("What we like about it", `<p>${esc(it.note || "—")}</p>`),
        it.url ? grp("Where it's from", `<div class="chips"><a class="chip" href="${esc(it.url)}" target="_blank" rel="noopener">${esc(domain(it.url))}${icon("out")}</a></div>`) : "",
        !d ? grp("No Lottie file yet", `<div class="chips">${it.url ? `<button class="chip" data-find="${it.id}">${icon("search")}Find the Lottie for me</button>` : ""}<button class="chip" data-addpic="${it.id}">${icon("image")}${it.image ? "Change the picture" : "Add a screenshot or GIF"}</button></div><p class="hint">(I look on the page for the animation file first; if it's hidden, Claude searches for it)</p>`) : "",
        size,
        more([colours, file, grp("Remove", `<button class="btn small" data-remove="${it.id}">${icon("trash")}Remove from Inspiration</button>`)])
      ].join("");
    }
    if (open.tab === "export") renderExport();
  }
  function verdictHTML(it, lv) {
    const s = stats(it); if (!s || !lv.budget) return "";
    const over = [s.layers > lv.budget.layers && "too many moving parts", s.colours > lv.budget.colours && "too many colours",
                  s.seconds > lv.budget.seconds && "too long", s.kb > lv.budget.kb && "too heavy"].filter(Boolean);
    return over.length ? `<p class="verdict bad">Too busy for this size: ${over.join(", ")}.</p>` : `<p class="verdict">${icon("check")}Simple enough for this size.</p>`;
  }
  function budgetHTML(it, lv) {
    const s = stats(it); if (!s || !lv.budget) return "";
    const rows = [["Moving parts", s.layers, lv.budget.layers, v => v], ["Colours", s.colours, lv.budget.colours, v => v],
                  ["Length", s.seconds, lv.budget.seconds, v => v.toFixed(1) + "s"], ["File size", s.kb, lv.budget.kb, v => v.toFixed(0) + "KB"]];
    return `<div class="budget">${rows.map(([n, v, max, f]) => `<div class="b${v > max ? " over" : ""}"><span>${n}</span><span class="bar"><i style="--p:${Math.min(100, (v / max) * 100)}%"></i></span><span class="v">${f(v)} / ${f(max)}</span></div>`).join("")}<p class="hint">(the limits for ${esc(lv.name)}, set in BRAND.md)</p></div>`;
  }
  function tc() { const a = open && open.anims[0]; if (!a) return; const d = data.get(open.item.id), f = Math.floor(a.currentFrame); $("#d-tc").textContent = `${(f / d.fr).toFixed(2)}s / ${((d.op - d.ip) / d.fr).toFixed(1)}s`; }
  function syncPlay() { const a = open && open.anims[0]; if (!a) return; const b = $("#d-play"); b.textContent = a.isPaused ? "▶" : "❚❚"; b.setAttribute("aria-label", a.isPaused ? "Play" : "Pause"); }

  $("#d-close").addEventListener("click", closeDetail);
  detail.addEventListener("click", async e => {
    if (e.target === detail) return closeDetail();
    const t = e.target;
    const m = t.closest("#d-mode [data-m]"); if (m && !m.disabled) { open.mode = m.dataset.m; renderStageOpts(); stage(); return; }
    const r = t.closest("#d-ratios [data-r]"); if (r) { open.ratio = r.dataset.r; renderStageOpts(); stage(); return; }
    const pl = t.closest("#d-place [data-pl]"); if (pl) { open.place = pl.dataset.pl; renderStageOpts(); stage(); if (open.tab === "export") renderExport(); return; }
    const b = t.closest("#d-bd [data-bd]"); if (b) { open.backdrop = b.dataset.bd; renderStageOpts(); if (open.tab === "export") renderExport(); return; }
    const tab = t.closest("#p-tabs [data-tab]"); if (tab) return setTab(tab.dataset.tab);
    if (t.closest("#x-body") && exportClick(t)) return;
    const st = t.closest("[data-st]"); if (st) { if (st.dataset.st === open.item.status) return; if (st.dataset.st === "retired") return openMenu(st, open.item, true); return setStatus(open.item, st.dataset.st); }
    const sp = t.closest("[data-set-panel]"); if (sp) return openMenu(sp, open.item, true);
    const j = t.closest("[data-jump]"); if (j) { const it = byId(j.dataset.jump); if (it) openDetail(it, open.ratio); return; }
    const rm = t.closest("[data-remove]"); if (rm) return removeInsp(byId(rm.dataset.remove));
    const fd = t.closest("[data-find]"); if (fd) return findLottie(byId(fd.dataset.find));
    const ap = t.closest("[data-addpic]"); if (ap) { picFor = byId(ap.dataset.addpic); return $("#pic-file").click(); }
    const pk = t.closest("[data-pick]");
    if (pk) {
      pk.disabled = true;
      try { const { job } = await post("api/pick", { id: open.item.id, key: pk.dataset.pick }); jobs.unshift(job); renderJobs(); poll(); closeDetail(); toast(`Claude is animating option ${pk.dataset.pick.toUpperCase()}. It'll come back to Needs you.`); window.scrollTo({ top: 0, behavior: "smooth" }); }
      catch (err) { pk.disabled = false; toast(err.message); }
    }
  });
  $("#d-prev").addEventListener("click", () => step(-1));
  $("#d-next").addEventListener("click", () => step(1));
  $("#d-play").addEventListener("click", () => { const a = open && open.anims[0]; if (!a) return; const play = a.isPaused; open.anims.forEach(x => (play ? x.play() : x.pause())); syncPlay(); });
  $("#d-scrub").addEventListener("input", e => { if (open) { open.anims.forEach(a => a.goToAndStop(+e.target.value, true)); syncPlay(); tc(); } });
  $("#d-save").addEventListener("click", toggleSave);
  $("#d-grow").addEventListener("click", grow);
  $("#d-export").addEventListener("click", () => setTab("export"));
  $("#x-download").addEventListener("click", () => runExport("download"));
  $("#x-copy").addEventListener("click", () => runExport("copy"));
  $("#d-note").addEventListener("click", note);
  function toggleSave() {
    if (!open) return; const id = open.item.id;
    saved.has(id) ? saved.delete(id) : saved.add(id); write(SAVED, [...saved]);
    renderPanel(); renderNav(); toast(saved.has(id) ? "Saved" : "Removed from Saved");
  }
  function grow() {
    if (!open) return; const it = open.item;
    closeDetail();
    $("#need").value = isInsp(it) ? `Something inspired by "${title(it)}" (${it.id}): ${it.note || ""} ` : `Like ${it.name} (${it.id}), but `;
    state.makeLevel = it.level || ""; state.makePlace = placeOf(it); state.view = "library"; save(); renderAll();
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => { const n = $("#need"); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }, 250);
  }
  function note() {
    if (!open) return; const it = open.item, a = open.anims[0], f = a ? Math.floor(a.currentFrame) : 0, d = data.get(it.id);
    copy(`Note on ${it.id} ${title(it)} at ${d ? (f / d.fr).toFixed(2) + "s" : "the start"}: [your note]
Scope: [just this one / every ${levelName(it.level)} Lottie / always]
Fix it, then log the note in NOTES.md with today's date and its scope.`, "Note copied. Paste it into Claude and fill in the brackets.");
  }

  addEventListener("keydown", e => {
    if (e.key === "Escape") {
      if (!$("#insp-modal").hidden) return closeModal();
      if (!menu.hidden) return closeMenu();
      if (!$("#view-pop").hidden) return togglePop(false);
      if (open) return closeDetail();
      return closeSide();
    }
    if (!open || e.target.matches("input, textarea, select") || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === "ArrowLeft") step(-1);
    else if (e.key === "ArrowRight") step(1);
    else if (e.key === " ") { e.preventDefault(); $("#d-play").click(); }
    else if (e.key.toLowerCase() === "d" && data.has(open.item.id) && open.item.status !== "pitch") setTab("export");
  });

  // ---------------- inspiration ----------------
  const modal = $("#insp-modal");
  let pending = null;
  let pendingPic = null, picFor = null;
  function readPic(file) {
    if (file.size > 15e6) return setDrop(null, "That picture is over 15MB.");
    setDrop(null, "Uploading the picture…");
    const fr = new FileReader();
    fr.onload = async () => {
      try { const { path } = await post("api/upload", { name: file.name, data: fr.result }); pendingPic = path; setDrop(file.name); $("#drop").classList.add("has"); }
      catch (err) { pendingPic = null; setDrop(null, err.message); }
    };
    fr.readAsDataURL(file);
  }
  async function findLottie(it) {
    if (!it) return;
    try { const { job } = await post("api/inspiration/find", { id: it.id }); jobs.unshift(job); renderJobs(); poll(); toast(`Looking for the Lottie behind “${title(it)}”…`); }
    catch (err) { toast(err.message); }
  }
  $("#pic-file").addEventListener("change", async e => {
    const file = e.target.files[0]; e.target.value = ""; if (!file || !picFor) return;
    const it = picFor; picFor = null;
    const fr = new FileReader();
    fr.onload = async () => {
      try {
        const { path } = await post("api/upload", { name: file.name, data: fr.result });
        const { item } = await post("api/inspiration/image", { id: it.id, image: path });
        Object.assign(it, item); renderAll(); if (open && open.item.id === it.id) { renderPanel(); stage(); }
        toast("Picture added");
      } catch (err) { toast(err.message); }
    };
    fr.readAsDataURL(file);
  });
  function openModal(file) {
    $("#insp-level").innerHTML = `<option value="">Not sure yet</option>` + catalog.levels.map(l => `<option value="${l.id}">${esc(l.name)} · ${esc(l.title)}</option>`).join("");
    $("#insp-form").reset(); pending = null; pendingPic = null; setDrop();
    modal.hidden = false;
    if (file) readFile(file); else setTimeout(() => $("#insp-url").focus(), 50);
  }
  function closeModal() { modal.hidden = true; pending = null; }
  function setDrop(name, err) {
    $("#drop").classList.toggle("has", !!name);
    $("#drop-label").innerHTML = err ? esc(err) : name ? `Added: <b>${esc(name)}</b> (click to change)` : `Drop a Lottie .json, or a screenshot / GIF of it, or <u>choose a file</u>`;
  }
  function readFile(file) {
    if (/^image\/(png|jpeg|webp|gif)$/.test(file.type)) return readPic(file);
    if (!/\.json$/i.test(file.name)) return setDrop(null, "Drop a Lottie .json, or a screenshot / GIF of it.");
    const r = new FileReader();
    r.onload = () => {
      try { const j = JSON.parse(r.result); if (!j.layers || !j.w) throw 0; pending = j; setDrop(file.name);
        if (!$("#insp-title").value) $("#insp-title").value = (j.nm || file.name.replace(/\.json$/i, "")).slice(0, 120); }
      catch (e) { pending = null; setDrop(null, "That file isn't a Lottie."); }
    };
    r.readAsText(file);
  }
  $("#insp-file").addEventListener("change", e => e.target.files[0] && readFile(e.target.files[0]));
  $("#insp-close").addEventListener("click", closeModal);
  $("#insp-cancel").addEventListener("click", closeModal);
  modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
  ["dragenter", "dragover"].forEach(t => $("#drop").addEventListener(t, e => { e.preventDefault(); $("#drop").classList.add("over"); }));
  ["dragleave", "drop"].forEach(t => $("#drop").addEventListener(t, e => { e.preventDefault(); $("#drop").classList.remove("over"); }));
  $("#drop").addEventListener("drop", e => { const f = e.dataTransfer.files[0]; if (f) readFile(f); });
  let dragDepth = 0;
  const hasFiles = e => [...((e.dataTransfer && e.dataTransfer.types) || [])].includes("Files");
  addEventListener("dragenter", e => { if (hasFiles(e)) { dragDepth++; document.body.classList.add("dragging"); } });
  addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove("dragging"); } });
  addEventListener("dragover", e => { if (hasFiles(e)) e.preventDefault(); });
  addEventListener("drop", e => {
    dragDepth = 0; document.body.classList.remove("dragging");
    if (e.target.closest("#drop")) return;
    const files = [...((e.dataTransfer && e.dataTransfer.files) || [])]; if (!files.length) return;
    e.preventDefault();
    const imgs = files.filter(f => /^image\/(png|jpeg|webp|gif)$/.test(f.type));
    if (imgs.length && modal.hidden && state.view !== "inspiration") {
      if (state.view !== "library") { state.view = "library"; save(); renderAll(); }
      addImages(imgs); $("#composer").scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const f = files[0]; if (modal.hidden) openModal(f); else readFile(f);
  });
  $("#insp-form").addEventListener("submit", async e => {
    e.preventDefault();
    const body = { title: $("#insp-title").value.trim(), url: $("#insp-url").value.trim(), note: $("#insp-note").value.trim(), level: $("#insp-level").value, lottie: pending || undefined, image: pendingPic || undefined };
    if (!body.url && !pending && !pendingPic) return toast("Add a link, a Lottie file or a picture.");
    const find = !pending && body.url && $("#insp-find").checked;
    try {
      const { item } = await post("api/inspiration", body);
      if (pending) { data.set(item.id, pending); sizes.set(item.id, JSON.stringify(pending).length); }
      insp.items.unshift(item); closeModal();
      state.view = "inspiration"; state.q = ""; save(); renderAll(); toast(`Added to Inspiration`);
      if (find) findLottie(item);
    } catch (err) { toast(err.message); }
  });
  async function removeInsp(it) {
    if (!it) return;
    try { await post("api/inspiration/remove", { id: it.id }); } catch (err) { return toast(err.message); }
    insp.items = insp.items.filter(i => i.id !== it.id); data.delete(it.id);
    if (open) closeDetail(); renderAll(); toast("Removed from Inspiration");
  }
  function renderSources() {
    $("#sources").innerHTML = `<span class="lbl">Where to look:</span>` + (insp.sources || []).map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener" title="${esc(s.why)}">${esc(s.name)}${icon("out")}</a>`).join("");
  }

  // ---------------- phone menu, clipboard, toast ----------------
  function closeSide() { document.body.classList.remove("side-open"); }
  $("#menu-btn").addEventListener("click", () => document.body.classList.add("side-open"));
  $("#side-close").addEventListener("click", closeSide);
  $("#side-scrim").addEventListener("click", closeSide);
  function copy(text, msg) {
    const done = () => toast(msg);
    if (navigator.clipboard && isSecureContext) navigator.clipboard.writeText(text).then(done, fallback); else fallback();
    function fallback() { const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); done(); } catch (e) {} ta.remove(); }
  }
  let tt;
  function toast(msg, undo) {
    const t = $("#toast"), u = $("#toast-undo");
    $("#toast-msg").textContent = msg;
    u.hidden = !undo; u.onclick = undo ? () => { t.classList.remove("show"); undo(); } : null;
    t.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("show"), undo ? 5000 : 3200);
  }

  // ---------------- boot ----------------
  let booted = false;
  async function loadJSON(path) { const r = await fetch(path, { cache: "no-store" }); if (!r.ok) throw new Error(path); const txt = await r.text(); return [JSON.parse(txt), txt.length]; }
  async function loadFiles(items) {
    await Promise.all(items.filter(i => i.file && !data.has(i.id)).map(async it => {
      try { const [j, n] = await loadJSON(it.file); data.set(it.id, j); sizes.set(it.id, n); } catch (e) { console.warn("Missing Lottie", it.file); }
    }));
  }
  async function boot() {
    try { [catalog] = await loadJSON("catalog.json"); }
    catch (e) { lib.innerHTML = `<p class="empty">Couldn't read catalog.json. Open this page through Claude ("open the Lottie library"), not by double-clicking the file.</p>`; return; }
    try { [insp] = await loadJSON("inspiration.json"); } catch (e) { insp = { items: [], sources: [] }; }
    catalog.levels = catalog.levels || [];
    await loadFiles(catalog.items.concat(insp.items));
    renderPlaceOpts(); renderMakeChips(); renderSources(); renderAll();
    await poll(); booted = true;
    const it = byId(location.hash.slice(1)); if (it) openDetail(it);
  }
  boot();
})();
