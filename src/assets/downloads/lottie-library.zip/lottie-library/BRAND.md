# Motion rules

The rulebook every Lottie in this library follows. Claude reads it before making anything.

**The colours below are placeholders** until the real brand tokens come in from the design system. Swap them here and in `tools/make_samples.py`.

Every change to this file gets a dated line in the Changelog at the bottom.

## What these Lotties are for

Mostly showing the app's UI: screens, flows and features, animated for the website and marketing. Shapes stand in for text (bars) and real screens (simple panels). No logos, no real customer data, no real prices unless they're anonymised.

## Levels: how big, and how busy

Every Lottie has a level. The level decides how much detail it's allowed.

| Level | Name | Where it sits | Shown at | Max moving parts (layers) | Max colours | Max length | Max file size |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Hero moment | The big moment at the top of a page. One per page. | 480–1200px wide | 40 | 8 | 6s | 300KB |
| 2 | Section | Beside copy in a section. A short story in two or three steps. | 280–520px | 24 | 5 | 4s | 150KB |
| 3 | Card | Small cards in a row of three or four. Low priority, one simple idea. | 96–200px | 10 | 3 | 2.5s | 50KB |
| 4 | Detail | Next to a price, inside a button or a toast. | 16–48px | 4 | 2 | 1.5s | 15KB |

- A Level 3 card has **one idea and two moves at most**. If it needs more, it's a Level 2.
- Level 4 must read at 16px: thick strokes, no thin lines, no text bars.
- The four Level 3 cards in a row should feel like one set: same coin, same weights, same timing.
- The page checks these limits for every Lottie ("Simple enough for this size").

## Placement: where a Lottie sits in its frame

Every Lottie has a placement (`placement` in catalog.json). Design for it from the first sketch.

| Placement | What the page does | Design for it by |
| --- | --- | --- |
| `safe` (default) | Shows the whole Lottie inside a 10% margin, whatever the frame shape. | Keeping nothing important touching the artboard edges. |
| `whole` | Shows the whole Lottie touching the frame's edges. | Composing right up to the artboard edges. |
| `fill` | Crops it to fill the frame. | Keeping the key action in the centre 60%. |
| `bottom` | Sits it flush on the frame's bottom edge and fades its bottom 40% into the background. | Rising up from the bottom edge (a phone or card cut off at the bottom); everything important in the top 55%. |

Exports (PNG, JPEG, SVG) use the same placement, so what the page shows is what exports.

## Colours (each has one job)

| Token | Hex | Job |
| --- | --- | --- |
| Brand | `#7A5CFA` (placeholder) | Buttons, coins, confirmations, the one thing to look at. |
| Up | `#2BB673` | **Only** for prices or balances going up. |
| Down | `#E5484D` | **Only** for prices or balances going down. |
| Screen | `#1C1E24` | App screen background. |
| Card | `#2A2D35` | Cards on the screen. |
| Line | `#3A3E48` | Outlines, idle controls. |
| Text | `#E8E9EC` | Text, drawn as rounded bars. |
| Muted | `#8A8F98` | Secondary text bars, guides. |

**Green and red mean market direction.** On an exchange people read green as "up" and red as "down", so never use them for success, errors, decoration or brand moments. A confirmation uses Brand, not green.

Never: gradients, glows, drop shadows, neon, rainbow data.

## Motion

| Token | Value | Use |
| --- | --- | --- |
| Settle (ease out) | `cubic-bezier(0.2, 0, 0, 1)` | Things arriving: growth, reveals, pops. The default. |
| Move (ease in-out) | `cubic-bezier(0.6, 0, 0.2, 1)` | Things travelling or drawing: lines, coins in flight. |
| Quick | 12–20 frames (0.2–0.33s) | Taps, pops. |
| Base | 30–40 frames (0.5–0.67s) | Most moves. |
| Slow | 80–120 frames (1.3–2s) | Chart lines drawing. |
| Stagger | 6 frames between siblings | |
| Corners | 8px on small parts, 16–18px on buttons and cards, 48px on phone frames | |

- 60fps, transparent background (the page supplies the background).
- Button presses dip to 95–96% and come back. Nothing bounces past 112%.
- One-shots play once and hold. Loops stay calm and never faster than once a second.

## Changelog
- 2026-11-11: Rewritten around levels 1–4 and app UI. Green and red reserved for market direction.
- 2026-11-11: Starter rules written.
