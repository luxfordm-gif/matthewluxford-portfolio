#!/bin/sh
# Starts the Lottie library on http://localhost:8123 and opens it in the browser.
# Needs Python 3 (built into macOS once the developer tools are installed).
cd "$(dirname "$0")" || exit 1
PORT="${1:-8123}"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 isn't installed. On a Mac, run: xcode-select --install"
  exit 1
fi
( sleep 1 && open "http://localhost:$PORT" 2>/dev/null || xdg-open "http://localhost:$PORT" 2>/dev/null ) &
exec python3 tools/serve.py "$PORT"
