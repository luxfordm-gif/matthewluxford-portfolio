"""Generates the starter Lotties: app-UI style demos at each of the four levels.

Every sample uses the tokens in BRAND.md (palette, easing, timing). The shapes
are generic app UI (no logos, no real screens). Swap the colours below for the
real brand tokens and re-run.

Once your own Lotties are in, this file can be deleted.
Run: python3 tools/make_samples.py   (from the lottie-library folder)
"""
import json, math, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---- Tokens (mirror BRAND.md; placeholders until the real brand tokens arrive)
def hex_rgba(h, a=1):
    h = h.lstrip('#')
    return [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)] + [a]

BRAND = hex_rgba('#7A5CFA')    # placeholder brand violet: buttons, coins, confirms
UP = hex_rgba('#2BB673')       # market up ONLY (price, balance, gains)
DOWN = hex_rgba('#E5484D')     # market down ONLY
SCREEN = hex_rgba('#1C1E24')   # app screen
CARD = hex_rgba('#2A2D35')     # cards on the screen
LINE = hex_rgba('#3A3E48')     # outlines, idle controls
TEXT = hex_rgba('#E8E9EC')     # text, drawn as bars
MUTE = hex_rgba('#8A8F98')     # secondary text bars, guides

FPS = 60
SETTLE = ([0.2], [0]), ([0.0], [1])   # things arriving
MOVE = ([0.6], [0]), ([0.2], [1])     # things travelling or drawing

# ---- Tiny Lottie builders -------------------------------------------------
def static(v):
    return {"a": 0, "k": v}

def anim(keys, ease=SETTLE):
    (ox, oy), (ix, iy) = ease
    k = []
    for n, (t, v) in enumerate(keys):
        kf = {"t": t, "s": v if isinstance(v, list) else [v]}
        if n < len(keys) - 1:
            kf["o"] = {"x": ox, "y": oy}
            kf["i"] = {"x": ix, "y": iy}
        k.append(kf)
    return {"a": 1, "k": k}

def tr(p=(0, 0)):
    return {"ty": "tr", "p": static(list(p)), "a": static([0, 0]), "s": static([100, 100]),
            "r": static(0), "o": static(100), "sk": static(0), "sa": static(0)}

def ellipse(size, p=(0, 0)):
    return {"ty": "el", "p": static(list(p)), "s": static([size, size])}

def rect(w, h, r=8, p=(0, 0)):
    return {"ty": "rc", "p": static(list(p)), "s": static([w, h]), "r": static(r)}

def path(points, closed=False):
    z = [[0, 0]] * len(points)
    return {"ty": "sh", "ks": static({"i": z, "o": z, "v": [list(p) for p in points], "c": closed})}

def fill(c, o=100):
    return {"ty": "fl", "c": static(c), "o": static(o), "r": 1}

def stroke(c, w=8, o=100):
    return {"ty": "st", "c": static(c), "o": static(o), "w": static(w), "lc": 2, "lj": 2, "ml": 4}

def trim(end):
    return {"ty": "tm", "s": static(0), "e": end, "o": static(0), "m": 1}

def group(items, name="g", p=(0, 0)):
    return {"ty": "gr", "nm": name, "it": items + [tr(p)]}

def layer(name, shapes, pos, op, scale=None, rot=None, opacity=None):
    return {"ddd": 0, "ind": 0, "ty": 4, "nm": name, "sr": 1,
            "ks": {"o": opacity or static(100), "r": rot or static(0),
                   "p": pos if isinstance(pos, dict) else static(list(pos) + [0]),
                   "a": static([0, 0, 0]), "s": scale or static([100, 100, 100])},
            "ao": 0, "shapes": shapes, "ip": 0, "op": op, "st": 0, "bm": 0}

def comp(name, w, h, op, layers):
    for i, l in enumerate(layers):   # first in the list draws on top
        l["ind"] = i + 1
    return {"v": "5.7.4", "fr": FPS, "ip": 0, "op": op, "w": w, "h": h,
            "nm": name, "ddd": 0, "assets": [], "layers": layers}

def fade_in(t, d=18):
    return anim([(t, [0]), (t + d, [100])])

def pop(t, peak=112):
    return anim([(t, [0, 0, 100]), (t + 12, [peak, peak, 100]), (t + 22, [100, 100, 100])])

# ---- Level 1 · Hero moment -------------------------------------------------
def portfolio_rise():
    """Phone screen: balance settles, chart draws up, gain card slides in, Buy pulses."""
    w, h, op = 1200, 900, 300
    px, py = 470, 450
    chart = [(-150, 90), (-110, 60), (-70, 75), (-30, 20), (10, 35), (50, -20), (90, -5), (150, -70)]
    end = chart[-1]
    return comp("L01 Portfolio Rise", w, h, op, [
        layer("gain card", [group([rect(110, 12, 6, (-50, -24)), fill(MUTE)], "label"),
                            group([rect(96, 30, 8, (-57, 16)), fill(UP)], "gain chip"),
                            group([rect(250, 104, 18), fill(CARD)], "bg")],
              anim([(150, [880, 600, 0]), (190, [820, 560, 0])]), op, opacity=fade_in(150, 24)),
        layer("end dot", [group([ellipse(18), fill(UP)])], (px + end[0], py + 10 + end[1]), op, scale=pop(156)),
        layer("chart", [group([path(chart), stroke(UP, 6), trim(anim([(40, [0]), (160, [100])], MOVE))])], (px, py + 10), op),
        layer("balance", [group([rect(210, 34, 8), fill(TEXT)])], (px - 55, py - 200), op,
              scale=anim([(10, [70, 100, 100]), (40, [100, 100, 100])]), opacity=fade_in(10)),
        layer("balance label", [group([rect(110, 12, 6), fill(MUTE)])], (px - 105, py - 240), op, opacity=fade_in(0)),
        layer("ranges", [group([rect(54, 26, 8, (-96 + i * 64, 0)), fill(BRAND if i == 0 else LINE)], f"r{i}") for i in range(4)],
              (px, py + 140), op, opacity=fade_in(20)),
        layer("buy button", [group([rect(300, 56, 16), fill(BRAND)])], (px, py + 290), op,
              scale=anim([(210, [100, 100, 100]), (220, [96, 96, 100]), (236, [100, 100, 100])])),
        layer("phone", [group([rect(110, 26, 13, (0, -350)), fill(hex_rgba('#0B0C0E'))], "notch"),
                        group([rect(380, 780, 48), fill(SCREEN), stroke(LINE, 3)], "body")], (px, py), op),
    ])

# ---- Level 2 · Section -----------------------------------------------------
def buy_flow():
    """Amount, tap Buy, confirmed."""
    w, h, op = 800, 800, 240
    out = anim([(120, [100]), (136, [0])])
    keys = [group([ellipse(14), fill(LINE)], f"k{r}{c}", ((c - 1) * 90, (r - 1) * 60)) for r in range(3) for c in range(3)]
    return comp("L02 Buy Flow", w, h, op, [
        layer("check", [group([path([(-28, 2), (-8, 22), (30, -18)]), stroke(TEXT, 10), trim(anim([(146, [0]), (172, [100])]))])],
              (400, 330), op),
        layer("confirm", [group([ellipse(140), fill(BRAND)])], (400, 330), op, scale=pop(130, 108)),
        layer("amount", [group([rect(240, 44, 10), fill(TEXT)])], (400, 230), op,
              scale=anim([(0, [80, 80, 100]), (30, [100, 100, 100])]), opacity=out),
        layer("currency", [group([rect(120, 14, 7), fill(MUTE)])], (400, 175), op, opacity=out),
        layer("keypad", keys, (400, 410), op, opacity=out),
        layer("buy button", [group([rect(400, 64, 18), fill(BRAND)])], (400, 600), op,
              scale=anim([(96, [100, 100, 100]), (106, [95, 95, 100]), (122, [100, 100, 100])])),
        layer("panel", [group([rect(520, 640, 32), fill(SCREEN), stroke(LINE, 3)])], (400, 400), op),
    ])

# ---- Level 3 · Card --------------------------------------------------------
def staking_reward():
    w, h, op = 400, 400, 150
    return comp("L03 Staking Reward", w, h, op, [
        layer("reward chip", [group([rect(110, 38, 12), fill(UP)])], anim([(30, [262, 150, 0]), (70, [262, 110, 0])]), op,
              opacity=anim([(30, [0]), (46, [100]), (112, [100]), (136, [0])])),
        layer("coin", [group([ellipse(96), stroke(TEXT, 6)], "ring"), group([ellipse(150), fill(BRAND)], "face")],
              anim([(0, [190, 220, 0]), (75, [190, 208, 0]), (150, [190, 220, 0])], MOVE), op),
    ])

def transfer():
    w, h, op = 400, 400, 150
    arc = [(-100, 0), (-60, -55), (0, -75), (60, -55), (100, 0)]
    coin_path = anim([(30 + i * 15, [200 + x, 230 + y, 0]) for i, (x, y) in enumerate(arc)], MOVE)
    return comp("L04 Transfer", w, h, op, [
        layer("coin", [group([ellipse(30), fill(BRAND)])], coin_path, op,
              opacity=anim([(26, [0]), (32, [100]), (92, [100]), (100, [0])])),
        layer("arc", [group([path(arc), stroke(MUTE, 4, 60), trim(anim([(10, [0]), (40, [100])], MOVE))])], (200, 230), op),
        layer("to", [group([ellipse(90), fill(LINE)])], (300, 250), op,
              scale=anim([(92, [100, 100, 100]), (102, [110, 110, 100]), (116, [100, 100, 100])])),
        layer("from", [group([ellipse(90), fill(LINE)])], (100, 250), op),
    ])

def price_alert():
    w, h, op = 400, 400, 150
    bell = [(-60, 100), (-50, 50), (-35, 15), (0, 0), (35, 15), (50, 50), (60, 100)]
    return comp("L05 Price Alert", w, h, op, [
        layer("badge", [group([ellipse(40), fill(BRAND)])], (248, 150), op, scale=pop(40)),
        layer("bell", [group([ellipse(26, (0, 112)), fill(TEXT)], "clapper"), group([path(bell, True), fill(TEXT)], "body")],
              (200, 140), op, rot=anim([(10, [0]), (22, [-14]), (34, [12]), (46, [-8]), (58, [4]), (70, [0])], MOVE)),
    ])

# ---- Level 4 · Detail ------------------------------------------------------
def price_tick():
    w = h = 96; op = 90
    return comp("L06 Price Tick", w, h, op, [
        layer("arrow", [group([path([(0, -16), (16, 8), (-16, 8)], True), fill(UP)])],
              anim([(0, [48, 54, 0]), (20, [48, 42, 0]), (34, [48, 46, 0])]), op),
        layer("flash", [group([rect(40, 6, 3), fill(UP)])], (48, 72), op, opacity=anim([(10, [0]), (22, [100]), (60, [100]), (80, [30])])),
    ])

def order_confirmed():
    w = h = 96; op = 90
    return comp("L08 Order Confirmed", w, h, op, [
        layer("tick", [group([path([(-14, 1), (-4, 11), (15, -9)]), stroke(BRAND, 7), trim(anim([(24, [0]), (44, [100])]))])], (48, 48), op),
        layer("ring", [group([ellipse(64), stroke(BRAND, 6), trim(anim([(0, [0]), (30, [100])], MOVE))])], (48, 48), op, rot=static(-90)),
    ])

# ---- Archived: kept to show what not to make -------------------------------
def wave_lines():
    w = h = 512; op = 120
    layers = []
    for i in range(7):
        y = 140 + i * 40
        pts = [(x, math.sin(x / 40 + i) * 18) for x in range(-200, 201, 40)]
        layers.append(layer(f"wave {i}", [group([path(pts), stroke(MUTE if i != 3 else UP, 3)])],
                            anim([(0, [236, y, 0]), (60, [276, y, 0]), (120, [236, y, 0])], MOVE), op))
    return comp("L07 Wave Lines", w, h, op, layers)

SAMPLES = {
    "lottie/L01-portfolio-rise.json": portfolio_rise,
    "lottie/L02-buy-flow.json": buy_flow,
    "lottie/L03-staking-reward.json": staking_reward,
    "lottie/L04-transfer.json": transfer,
    "lottie/L05-price-alert.json": price_alert,
    "lottie/L06-price-tick.json": price_tick,
    "lottie/L08-order-confirmed.json": order_confirmed,
    "_archive/L07-wave-lines.json": wave_lines,
}

if __name__ == "__main__":
    for rel, fn in SAMPLES.items():
        with open(os.path.join(ROOT, rel), "w") as f:
            json.dump(fn(), f, separators=(",", ":"))
        print("wrote", rel)
