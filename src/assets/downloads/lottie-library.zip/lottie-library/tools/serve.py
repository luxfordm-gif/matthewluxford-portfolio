"""Local server for the Lottie library.

Serves the folder (caching off, so edits always show) and handles the page's
few writes:

  POST /api/status       Keep / In review / Archive a Lottie (moves the file,
                         logs the reason in NOTES.md)
  POST /api/make         "Make it": runs Claude Code on the request; Claude
                         sketches three stills and adds a "pitch" entry
  POST /api/pick         You picked a sketch: Claude animates it -> "review"
  GET  /api/jobs         What Claude is working on
  POST /api/inspiration  Add a link or someone else's Lottie to Inspiration
  POST /api/inspiration/remove

Only requests from the library page itself are accepted (Origin and Host are
checked), so other websites can't trigger anything. Listens on 127.0.0.1 only.

Run: python3 tools/serve.py [port]   (the .claude/launch.json config does this)
"""
import base64
import datetime
import http.server
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import io
import re
import urllib.parse
import urllib.request
import uuid
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8123
CATALOG = os.path.join(ROOT, "catalog.json")
NOTES = os.path.join(ROOT, "NOTES.md")
INSP = os.path.join(ROOT, "inspiration.json")
STATUSES = {"approved": "Kept", "review": "Moved to review", "retired": "Archived"}
ALLOWED_HOSTS = {f"localhost:{PORT}", f"127.0.0.1:{PORT}"}

# ---- "Make it": Claude Code jobs ------------------------------------------
JOBS = {}            # job id -> dict
JOBS_LOCK = threading.Lock()
CLAUDE = shutil.which("claude") or os.path.expanduser("~/.local/bin/claude")
INBOX = os.path.join(ROOT, "refs", "inbox")
IMAGE_TYPES = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}


def load_config():
    """tools/config.json lists the Figma connector's read-only tools (names differ per computer)."""
    try:
        with open(os.path.join(ROOT, "tools", "config.json")) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


CONFIG = load_config()
# Files only (no shell, no web), plus the Figma connector's read-only tools if they're set up.
TOOLS = ",".join(["Read", "Write", "Edit", "Glob", "Grep"] + list(CONFIG.get("figma_tools", [])))

PLACEMENT_BRIEF = {
    "safe": "Placement: Safe area. The page shows the whole Lottie inside a 10% margin, whatever the frame shape, so compose freely inside the artboard but keep nothing important touching its edges.",
    "whole": "Placement: Edge to edge. The page shows the whole Lottie touching the frame's edges, so compose right up to the artboard edges.",
    "fill": "Placement: Fill. The page crops the Lottie to fill different frame shapes, so keep the key action in the centre 60% of the artboard.",
    "bottom": "Placement: Bottom, faded. The page sits the Lottie flush on the bottom edge of the frame and fades out its bottom 40%, so compose it rising up from the bottom edge (a phone or card cut off at the bottom works well) and keep everything important in the top 55%.",
}


def next_lottie_id(cat):
    used = [int(i["id"][1:]) for i in cat["items"] if i["id"][1:].isdigit()]
    with JOBS_LOCK:
        used += [int(j["item"][1:]) for j in JOBS.values() if j["state"] == "running"]
    return f"L{(max(used) + 1) if used else 1:02d}"


def level_line(cat, level_id):
    lv = next((l for l in cat.get("levels", []) if l["id"] == level_id), None)
    if not lv:
        return "Level: not chosen. Pick the right level from catalog.json and say why in the notes."
    b = lv.get("budget", {})
    return (f"Level: {lv['name']} · {lv['title']} ({lv['sub']} Shown at {lv['size']}.) "
            f"Stay inside its limits: at most {b.get('layers')} layers, {b.get('colours')} colours, "
            f"{b.get('seconds')} seconds, {b.get('kb')}KB.")


def refs_brief(refs, figma):
    lines = []
    if refs:
        lines.append("Reference images Matt attached (open each with the Read tool and study them before sketching): " + ", ".join(refs) + ".")
    if figma:
        if CONFIG.get("figma_tools"):
            lines.append("Figma frames Matt linked (use the Figma tools to get a screenshot and the design context of each): " + ", ".join(figma) + ".")
        else:
            lines.append("Figma links Matt added (the Figma tools aren't set up on this computer, so note in the entry's notes that you couldn't open them): " + ", ".join(figma) + ".")
    if lines:
        lines.append("Match their layout and content, but draw it in our BRAND.md style; never copy logos or real customer data.")
    return "\n".join(lines)


def pitch_prompt(item_id, need, level, placement, refs=(), figma=()):
    today = datetime.date.today().isoformat()
    return f"""You are working inside a Lottie animation library. Read CLAUDE.md, BRAND.md, NOTES.md and catalog.json first and follow them.

New request from Matt: "{need}"
{level}
{PLACEMENT_BRIEF.get(placement, PLACEMENT_BRIEF["safe"])}
{refs_brief(refs, figma)}

Do the PITCH step only (no animating yet):
1. Pick the closest approved Lottie(s) in catalog.json to grow from, and look at their JSON in lottie/ for our style.
2. Draw three clearly different options as still SVG images of the key moment: stills/{item_id}/a.svg, b.svg and c.svg. Use the BRAND.md palette, a transparent background, and the artboard size you'd animate at.
3. Add ONE entry to the "items" list in catalog.json with id "{item_id}", status "pitch", file "", added "{today}", placement "{placement}", and name, level (one of "1", "2", "3", "4"), use_for, not_for, tied_to, grown_from, tags, notes, plus
   "pitch": {{"need": the request, "options": [{{"key": "a", "file": "stills/{item_id}/a.svg", "idea": "one short line"}}, ... for b and c]}}.
Keep catalog.json valid JSON. Don't change any other entry or file.
Finish with one short line naming the three options."""


def animate_prompt(item, key):
    opt = next((o for o in item.get("pitch", {}).get("options", []) if o.get("key") == key), {"key": key, "idea": ""})
    slug = "".join(c if c.isalnum() else "-" for c in item.get("name", "lottie").lower()).strip("-")[:40] or "lottie"
    return f"""You are working inside a Lottie animation library. Read CLAUDE.md, BRAND.md, NOTES.md and catalog.json first and follow them.

Matt picked option "{key}" for {item['id']} {item.get('name', '')}: {opt.get('idea', '')} (still: {opt.get('file', '')}).
Request: "{item.get('pitch', {}).get('need', '')}"
{PLACEMENT_BRIEF.get(item.get('placement'), PLACEMENT_BRIEF["safe"])}
{refs_brief(item.get('refs', []), item.get('figma', []))}

Do the ANIMATE step:
1. Animate that still as a Lottie JSON (bodymovin 5.7 shape layers, 60fps, transparent background) at lottie/{item['id']}-{slug}.json. Follow BRAND.md for palette, easing and timing, and stay inside the level's limits. Study one or two existing files in lottie/ for the structure we use.
2. Re-read the file you wrote and make sure it's valid JSON with w, h, fr, ip, op and layers.
3. Update {item['id']} in catalog.json: status "review", file set to that path, keep "pitch" but add "picked": "{key}", and update notes with what moves and when.
Keep catalog.json valid JSON. Don't change any other entry.
Finish with one short line describing the animation."""


def run_job(job_id, prompt):
    job = JOBS[job_id]
    try:
        proc = subprocess.run(
            [CLAUDE, "-p", prompt, "--permission-mode", "acceptEdits", "--allowedTools", TOOLS, "--output-format", "json"],
            # own session: a server restart doesn't stop Claude mid-job; its result still lands in catalog.json
            cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=20 * 60, start_new_session=True)
        try:
            out = json.loads(proc.stdout or "{}")
        except json.JSONDecodeError:
            out = {"result": (proc.stdout or "")[-400:]}
        failed = proc.returncode != 0 or out.get("is_error")
        msg = (out.get("result") or proc.stderr or "").strip()[-400:]
        if failed and ("authenticat" in msg.lower() or "login" in msg.lower() or "oauth" in msg.lower()):
            msg = "Claude Code on this computer is signed out. Ask Claude in the app to sign it in (it runs: claude auth login), then try again."
        job.update(state="failed" if failed else "done", message=msg)
        if not failed and job.get("extra"):
            try:
                with open(CATALOG) as f:
                    cat = json.load(f)
                item = next((i for i in cat["items"] if i["id"] == job["item"]), None)
                if item:
                    for k, v in job["extra"].items():
                        if v and not item.get(k):
                            item[k] = v
                    write_json(CATALOG, cat)
            except (OSError, json.JSONDecodeError):
                pass
        if failed and job["kind"] == "pitch":   # don't leave an empty sketches folder behind
            d = os.path.join(ROOT, "stills", job["item"])
            if os.path.isdir(d) and not os.listdir(d):
                os.rmdir(d)
    except FileNotFoundError:
        job.update(state="failed", message="Claude Code isn't installed on this computer (no 'claude' command found).")
    except subprocess.TimeoutExpired:
        job.update(state="failed", message="Claude took longer than 20 minutes and was stopped.")
    except Exception as e:   # keep the server alive whatever happens
        job.update(state="failed", message=str(e)[:400])
    job["finished"] = time.time()


def start_job(kind, item_id, prompt, label, extra=None):
    job_id = f"{kind}-{item_id}-{int(time.time())}"
    with JOBS_LOCK:
        JOBS[job_id] = {"id": job_id, "kind": kind, "item": item_id, "label": label, "state": "running",
                        "started": time.time(), "finished": None, "message": "", "extra": extra or {}}
    threading.Thread(target=run_job, args=(job_id, prompt), daemon=True).start()
    return JOBS[job_id]


# ---- Inspiration: "Find the Lottie for me" ----------------------------------
FETCH_HEADERS = {"User-Agent": "Mozilla/5.0 (Macintosh) LottieLibrary/1.0", "Accept": "*/*"}
# The extension must end the path (so "api.lottielab.com" doesn't count as a .lottie file)
URL_RE = re.compile(r"""https?:(?:\\?/){2}[^\s"'<>()]+?\.(?:json|lottie)(?=[?#"'\s<>()\\]|$)(?:\?[^\s"'<>()\\]*)?""", re.I)
SRC_RE = re.compile(r"""(?:src|data-src|data-animation-path|path)\s*=\s*["']([^"']+?\.(?:json|lottie)(?:\?[^"']*)?)["']""", re.I)


def fetch(url, limit):
    if not url.startswith(("http://", "https://")):
        raise ValueError("not a web link")
    req = urllib.request.Request(url, headers=FETCH_HEADERS)
    with urllib.request.urlopen(req, timeout=20) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("too big")
    return data


def as_lottie(raw):
    """A Lottie dict from .json bytes or a .lottie (zip) file, or None."""
    try:
        if raw[:2] == b"PK":
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                names = [n for n in z.namelist() if n.startswith("animations/") and n.endswith(".json")]
                if not names:
                    return None
                raw = z.read(names[0])
        d = json.loads(raw.decode("utf-8"))
        return d if isinstance(d, dict) and {"layers", "w", "h", "op"} <= d.keys() else None
    except (ValueError, zipfile.BadZipFile, UnicodeDecodeError, KeyError):
        return None


def candidates(page_url, html):
    """Animation-file links on the page, the one for this page first.
    Pages often list related animations too, so a link that sits right after the page's own
    name (its last path segment, e.g. "bento-blocks-search-card") is ranked first."""
    slug = urllib.parse.urlparse(page_url).path.rstrip("/").split("/")[-1].lower()
    found = []   # (rank, position, url)
    for m in URL_RE.finditer(html):
        near = html[max(0, m.start() - 400):m.start()].lower()
        found.append((0 if slug and slug in near else 1, m.start(), m.group(0).replace("\\/", "/")))
    for m in SRC_RE.finditer(html):
        found.append((1, m.start(), urllib.parse.urljoin(page_url, m.group(1))))
    seen, out = set(), []
    for _, _, u in sorted(found):
        if u not in seen and not u.endswith(("package.json", "manifest.json")):
            seen.add(u)
            out.append(u)
    return out[:12]


def first_lottie(urls):
    for u in urls:
        try:
            d = as_lottie(fetch(u, 12_000_000))
        except Exception:
            continue
        if d:
            return u, d
    return None, None


def find_prompt(url, title):
    return f"""Find the Lottie animation file behind this page: {url} ("{title}").
Look at the page (WebFetch) and, if it helps, search for the same animation (WebSearch). I need a DIRECT link to the animation file itself: a .json Lottie or a .lottie file, not a web page.
Reply with up to three lines, best first, each exactly like:
LOTTIE_URL: https://...
If you can't find one, reply: LOTTIE_URL: none"""


def run_find(job_id, item_id, url, title):
    job = JOBS[job_id]
    try:
        html = fetch(url, 6_000_000).decode("utf-8", "replace")
        src, d = first_lottie(candidates(url, html))
    except Exception:
        src, d = None, None
    if not d and os.path.exists(CLAUDE):   # the page hides it: ask Claude to look
        job["label"] = f"Asking Claude to find the Lottie for {item_id}"
        try:
            proc = subprocess.run([CLAUDE, "-p", find_prompt(url, title), "--allowedTools", "WebFetch,WebSearch", "--output-format", "json"],
                                  cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=8 * 60)
            out = json.loads(proc.stdout or "{}").get("result") or ""
            urls = [u for u in re.findall(r"LOTTIE_URL:\s*(\S+)", out) if u.startswith("http")]
            src, d = first_lottie(urls)
        except Exception:
            pass
    if d:
        with open(INSP) as f:
            insp = json.load(f)
        item = next((i for i in insp["items"] if i["id"] == item_id), None)
        if item:
            slug = "".join(c if c.isalnum() else "-" for c in item.get("title", "lottie").lower()).strip("-")[:40] or "lottie"
            rel = f"inspiration/{item_id}-{slug}.json"
            os.makedirs(os.path.join(ROOT, "inspiration"), exist_ok=True)
            with open(os.path.join(ROOT, rel), "w") as f:
                json.dump(d, f, separators=(",", ":"))
            item["file"], item["source_file"] = rel, src
            write_json(INSP, insp)
        job.update(state="done", message=f"Found it: {src}")
    else:
        job.update(state="failed", message="Couldn't find a Lottie file behind that page. Add a screenshot or GIF of it instead.")
    job["finished"] = time.time()


def move_inbox_image(rel, dest_rel_stem):
    """Move an uploaded image from refs/inbox to dest (keeps the extension). Returns the new path or None."""
    src = os.path.realpath(os.path.join(ROOT, str(rel or "")))
    if os.path.dirname(src) != os.path.realpath(INBOX) or not os.path.isfile(src):
        return None
    dest_rel = dest_rel_stem + os.path.splitext(src)[1]
    os.makedirs(os.path.dirname(os.path.join(ROOT, dest_rel)), exist_ok=True)
    shutil.move(src, os.path.join(ROOT, dest_rel))
    return dest_rel


def write_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def log_note(today, item, status, reason):
    """Add a row to the top of the NOTES.md table (newest first)."""
    if not os.path.exists(NOTES):
        return
    reason = reason.replace("|", "/").strip()
    row = f"| {today} | {item['id']} {item['name']} | — | {STATUSES[status]}: {reason} | just here |\n"
    with open(NOTES) as f:
        lines = f.readlines()
    for i, line in enumerate(lines):
        if line.startswith("| ---"):
            lines.insert(i + 1, row)
            break
    else:
        lines.append(row)
    with open(NOTES, "w") as f:
        f.writelines(lines)


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        if self.command == "POST":
            super().log_message(fmt, *args)

    def reply(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def same_origin(self):
        """Only the library page may write: blocks other websites (CSRF) and DNS rebinding."""
        if self.headers.get("Host", "") not in ALLOWED_HOSTS:
            return False
        origin = self.headers.get("Origin", "")
        return origin.split("//", 1)[-1] in ALLOWED_HOSTS if origin else False

    def do_GET(self):
        if self.path.split("?")[0] == "/api/jobs":
            if self.headers.get("Host", "") not in ALLOWED_HOSTS:
                return self.reply(403, {"error": "forbidden"})
            with JOBS_LOCK:
                jobs = [{k: v for k, v in j.items() if k != "extra"} for j in sorted(JOBS.values(), key=lambda j: -j["started"])[:20]]
            return self.reply(200, {"jobs": jobs, "claude": os.path.exists(CLAUDE)})
        return super().do_GET()

    def do_POST(self):
        if not self.same_origin():
            return self.reply(403, {"error": "Requests must come from the library page."})
        try:
            n = int(self.headers.get("Content-Length", 0))
            cap = 22_000_000 if self.path == "/api/upload" else 5_000_000
            if n > cap:
                return self.reply(413, {"error": "That's too big (images up to 15MB)."})
            req = json.loads(self.rfile.read(n) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self.reply(400, {"error": "bad json"})
        if self.path == "/api/upload":
            return self.upload(req)
        if self.path == "/api/make":
            return self.make(req)
        if self.path == "/api/pick":
            return self.pick(req)
        if self.path == "/api/inspiration":
            return self.add_inspiration(req)
        if self.path == "/api/inspiration/remove":
            return self.remove_inspiration(req)
        if self.path == "/api/inspiration/find":
            return self.find_inspiration(req)
        if self.path == "/api/inspiration/image":
            return self.image_inspiration(req)
        if self.path != "/api/status":
            return self.reply(404, {"error": "not found"})
        item_id, status = req.get("id"), req.get("status")
        reason = (req.get("reason") or "").strip()[:300]
        if status not in STATUSES:
            return self.reply(400, {"error": "status must be approved, review or retired"})

        with open(CATALOG) as f:
            cat = json.load(f)
        item = next((i for i in cat["items"] if i["id"] == item_id), None)
        if not item:
            return self.reply(404, {"error": f"no Lottie {item_id}"})

        today = datetime.date.today().isoformat()
        folder = "_archive" if status == "retired" else "lottie"
        new_rel = f"{folder}/{os.path.basename(item['file'])}" if item.get("file") else ""
        if new_rel and new_rel != item["file"]:
            src, dst = os.path.join(ROOT, item["file"]), os.path.join(ROOT, new_rel)
            if os.path.exists(src):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.move(src, dst)
            item["file"] = new_rel

        item["status"] = status
        if status == "retired":
            item["retired"] = today
            if reason:
                item["retired_why"] = reason
        else:
            item.pop("retired", None)
            item.pop("retired_why", None)
        item.setdefault("history", []).append({"date": today, "status": status, **({"why": reason} if reason else {})})
        cat["updated"] = today
        write_json(CATALOG, cat)
        if reason or status == "retired":
            log_note(today, item, status, reason or "no reason given")
        self.reply(200, {"item": item})

    # ---- Reference images for Make it ----
    def upload(self, req):
        data = req.get("data") or ""
        head, _, b64 = data.partition(",")
        mime = head[5:].split(";")[0] if head.startswith("data:") else ""
        if mime not in IMAGE_TYPES or not b64:
            return self.reply(400, {"error": "Only PNG, JPEG, WebP or GIF images."})
        try:
            raw = base64.b64decode(b64, validate=True)
        except ValueError:
            return self.reply(400, {"error": "That image couldn't be read."})
        if len(raw) > 15_000_000:
            return self.reply(413, {"error": "That image is over 15MB."})
        stem = os.path.splitext(os.path.basename(req.get("name") or "image"))[0]
        stem = "".join(c if c.isalnum() else "-" for c in stem.lower()).strip("-")[:40] or "image"
        os.makedirs(INBOX, exist_ok=True)
        name = f"{uuid.uuid4().hex[:8]}-{stem}{IMAGE_TYPES[mime]}"
        with open(os.path.join(INBOX, name), "wb") as f:
            f.write(raw)
        self.reply(200, {"path": f"refs/inbox/{name}"})

    # ---- Make it ----
    def make(self, req):
        need = (req.get("need") or "").strip()[:1200]
        if len(need) < 6:
            return self.reply(400, {"error": "Describe the Lottie you need in a sentence or two."})
        if not os.path.exists(CLAUDE):
            return self.reply(500, {"error": "Claude Code isn't installed on this computer, so the page can't make Lotties. Paste the request into Claude instead."})
        with open(CATALOG) as f:
            cat = json.load(f)
        item_id = next_lottie_id(cat)
        os.makedirs(os.path.join(ROOT, "stills", item_id), exist_ok=True)
        placement = req.get("placement") if req.get("placement") in PLACEMENT_BRIEF else "safe"
        # Move the attached images out of the inbox and next to the sketches
        refs = []
        for rel in (req.get("refs") or [])[:40]:
            src = os.path.realpath(os.path.join(ROOT, str(rel)))
            if os.path.dirname(src) != os.path.realpath(INBOX) or not os.path.isfile(src):
                continue
            dest_dir = os.path.join(ROOT, "stills", item_id, "refs")
            os.makedirs(dest_dir, exist_ok=True)
            shutil.move(src, os.path.join(dest_dir, os.path.basename(src)))
            refs.append(f"stills/{item_id}/refs/{os.path.basename(src)}")
        figma = [u for u in (req.get("figma") or [])[:20]
                 if isinstance(u, str) and u.startswith(("https://www.figma.com/", "https://figma.com/"))]
        prompt = pitch_prompt(item_id, need, level_line(cat, req.get("level") or ""), placement, refs, figma)
        job = start_job("pitch", item_id, prompt, f"Sketching three options for {item_id}",
                        extra={"placement": placement, "refs": refs, "figma": figma})
        job["refs"], job["figma"], job["placement"] = len(refs), len(figma), placement
        self.reply(200, {"job": {k: v for k, v in job.items() if k != "extra"}})

    def pick(self, req):
        with open(CATALOG) as f:
            cat = json.load(f)
        item = next((i for i in cat["items"] if i["id"] == req.get("id")), None)
        if not item or item.get("status") != "pitch":
            return self.reply(400, {"error": "That sketch isn't waiting to be picked."})
        key = req.get("key")
        if key not in {o.get("key") for o in item.get("pitch", {}).get("options", [])}:
            return self.reply(400, {"error": "Unknown option."})
        job = start_job("animate", item["id"], animate_prompt(item, key), f"Animating {item['id']} {item.get('name', '')}, option {key.upper()}")
        self.reply(200, {"job": {k: v for k, v in job.items() if k != "extra"}})

    # ---- Inspiration: other people's Lotties and links, kept apart from ours ----
    def add_inspiration(self, req):
        title = (req.get("title") or "").strip()[:120]
        url = (req.get("url") or "").strip()[:500]
        lottie = req.get("lottie")
        if not title and not url and not lottie and not req.get("image"):
            return self.reply(400, {"error": "Add a link, a Lottie file or a picture."})
        if url and not url.startswith(("http://", "https://")):
            return self.reply(400, {"error": "links must start with http:// or https://"})
        if lottie is not None and not (isinstance(lottie, dict) and "layers" in lottie and "w" in lottie):
            return self.reply(400, {"error": "that file isn't a Lottie JSON"})
        with open(INSP) as f:
            insp = json.load(f)
        nums = [int(i["id"][1:]) for i in insp["items"] if i["id"][1:].isdigit()]
        new_id = f"I{(max(nums) + 1) if nums else 1:02d}"
        title = title or (lottie or {}).get("nm") or url.split("//")[-1].split("/")[0]
        slug = "".join(c if c.isalnum() else "-" for c in title.lower()).strip("-")[:40] or "lottie"
        item = {"id": new_id, "title": title, "url": url,
                "note": (req.get("note") or "").strip()[:600],
                "kind": req.get("kind") or "", "level": req.get("level") or "",
                "added": datetime.date.today().isoformat()}
        if lottie is not None:
            rel = f"inspiration/{new_id}-{slug}.json"
            os.makedirs(os.path.join(ROOT, "inspiration"), exist_ok=True)
            with open(os.path.join(ROOT, rel), "w") as f:
                json.dump(lottie, f, separators=(",", ":"))
            item["file"] = rel
        image = move_inbox_image(req.get("image"), f"inspiration/{new_id}-{slug}")
        if image:
            item["image"] = image
        insp["items"].insert(0, item)
        write_json(INSP, insp)
        self.reply(200, {"item": item})

    def find_inspiration(self, req):
        with open(INSP) as f:
            insp = json.load(f)
        item = next((i for i in insp["items"] if i["id"] == req.get("id")), None)
        if not item or not item.get("url"):
            return self.reply(400, {"error": "That idea has no link to look at."})
        job_id = f"find-{item['id']}-{int(time.time())}"
        with JOBS_LOCK:
            JOBS[job_id] = {"id": job_id, "kind": "find", "item": item["id"], "label": f"Looking for the Lottie behind {item['id']}",
                            "state": "running", "started": time.time(), "finished": None, "message": "", "extra": {}}
        threading.Thread(target=run_find, args=(job_id, item["id"], item["url"], item.get("title", "")), daemon=True).start()
        self.reply(200, {"job": {k: v for k, v in JOBS[job_id].items() if k != "extra"}})

    def image_inspiration(self, req):
        with open(INSP) as f:
            insp = json.load(f)
        item = next((i for i in insp["items"] if i["id"] == req.get("id")), None)
        if not item:
            return self.reply(404, {"error": "not found"})
        slug = "".join(c if c.isalnum() else "-" for c in item.get("title", "image").lower()).strip("-")[:40] or "image"
        image = move_inbox_image(req.get("image"), f"inspiration/{item['id']}-{slug}-{uuid.uuid4().hex[:4]}")
        if not image:
            return self.reply(400, {"error": "Upload the picture first."})
        item["image"] = image
        write_json(INSP, insp)
        self.reply(200, {"item": item})

    def remove_inspiration(self, req):
        with open(INSP) as f:
            insp = json.load(f)
        item = next((i for i in insp["items"] if i["id"] == req.get("id")), None)
        if not item:
            return self.reply(404, {"error": "not found"})
        insp["items"].remove(item)
        for key in ("file", "image"):
            if item.get(key, "").startswith("inspiration/"):
                path = os.path.join(ROOT, item[key])
                if os.path.exists(path):
                    os.remove(path)
        write_json(INSP, insp)
        self.reply(200, {"removed": item["id"]})


def clean_inbox(max_age=24 * 3600):
    if not os.path.isdir(INBOX):
        return
    now = time.time()
    for name in os.listdir(INBOX):
        path = os.path.join(INBOX, name)
        if os.path.isfile(path) and now - os.path.getmtime(path) > max_age:
            os.remove(path)


if __name__ == "__main__":
    clean_inbox()
    http.server.ThreadingHTTPServer.allow_reuse_address = True
    with http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler) as httpd:
        print(f"Lottie library on http://localhost:{PORT}")
        httpd.serve_forever()
